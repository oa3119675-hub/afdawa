module.exports = {
    name: 'messageLogger',
    execute(client) {
        client.on('ready', () => {
            console.log('System Message Logger ✅');
        });

        const logChannelId = process.env.LOG_CHANNEL;

        // تسجيل حذف الرسائل
        client.on('messageDelete', async message => {
            if (message.partial) return;
            if (message.author.bot) return;

            if (!logChannelId) return;

            try {
                const logChannel = message.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send({
                    content: `🗑️ **تم حذف رسالة!**
**المرسل:** ${message.author.tag}
**القناة:** ${message.channel}
**المحتوى:** ${message.content || 'لا يوجد نص'}`
                });
            } catch (error) {
                console.error('❌ خطأ في تسجيل حذف الرسالة:', error.message);
            }
        });

        // تسجيل تعديل الرسائل
        client.on('messageUpdate', async (oldMessage, newMessage) => {
            if (oldMessage.author.bot) return;
            if (oldMessage.content === newMessage.content) return;

            if (!logChannelId) return;

            try {
                const logChannel = oldMessage.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send({
                    content: `✏️ **تم تعديل رسالة!**
**المرسل:** ${oldMessage.author.tag}
**القناة:** ${oldMessage.channel}
**القديم:** ${oldMessage.content || 'لا يوجد نص'}
**الجديد:** ${newMessage.content || 'لا يوجد نص'}`
                });
            } catch (error) {
                console.error('❌ خطأ في تسجيل تعديل الرسالة:', error.message);
            }
        });

        // تسجيل انضمام الأعضاء
        client.on('guildMemberAdd', async member => {
            if (!logChannelId) return;

            try {
                const logChannel = member.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send(`✅ **انضم عضو جديد:** ${member.user.tag}`);
            } catch (error) {
                console.error('❌ خطأ في تسجيل انضمام عضو:', error.message);
            }
        });

        // تسجيل مغادرة الأعضاء
        client.on('guildMemberRemove', async member => {
            if (!logChannelId) return;

            try {
                const logChannel = member.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send(`❌ **خرج عضو:** ${member.user.tag}`);
            } catch (error) {
                console.error('❌ خطأ في تسجيل مغادرة عضو:', error.message);
            }
        });
    }
};
