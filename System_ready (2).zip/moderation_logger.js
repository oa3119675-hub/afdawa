module.exports = {
    name: 'moderationLogger',
    execute(client) {
        client.on('ready', () => {
            console.log('System Moderation Logger ✅');
        });

        // تسجيل الباند
        client.on('guildBanAdd', async (ban) => {
            const logChannelId = process.env.LOG_CHANNEL;
            if (!logChannelId) return;

            try {
                const logChannel = ban.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send(`⛔ **تم باند العضو:** ${ban.user.tag}\n**السبب:** ${ban.reason || 'غير محدد'}`);
            } catch (error) {
                console.error('❌ خطأ في تسجيل الباند:', error.message);
            }
        });

        // تسجيل فك الباند
        client.on('guildBanRemove', async (ban) => {
            const logChannelId = process.env.LOG_CHANNEL;
            if (!logChannelId) return;

            try {
                const logChannel = ban.guild.channels.cache.get(logChannelId);
                if (!logChannel) return;

                await logChannel.send(`✅ **تم فك الباند عن العضو:** ${ban.user.tag}`);
            } catch (error) {
                console.error('❌ خطأ في تسجيل فك الباند:', error.message);
            }
        });

        // تسجيل التايم أوت
        client.on('guildMemberUpdate', async (oldMember, newMember) => {
            const logChannelId = process.env.LOG_CHANNEL;
            if (!logChannelId) return;

            try {
                // تسجيل Timeout
                if (oldMember.communicationDisabledUntilTimestamp !== newMember.communicationDisabledUntilTimestamp) {
                    const logChannel = newMember.guild.channels.cache.get(logChannelId);
                    if (!logChannel) return;

                    const until = new Date(newMember.communicationDisabledUntilTimestamp).toLocaleString();
                    await logChannel.send(`⏱️ **تم تيم أوت العضو:** ${newMember.user.tag}\n**ينتهي عند:** ${until}`);
                }
            } catch (error) {
                console.error('❌ خطأ في تسجيل التايم أوت:', error.message);
            }
        });
    }
};
