const { PermissionsBitField, ChannelType } = require('discord.js');

module.exports = {
    name: 'persistentChannel',
    execute(client) {
        client.on('ready', async () => {
            console.log('System Persistent Channel ✅');

            // Get all guilds the bot is in
            client.guilds.cache.forEach(async (guild) => {
                const channelName = 'always-open';
                let channel = guild.channels.cache.find(c => c.name === channelName);

                if (!channel) {
                    try {
                        channel = await guild.channels.create({
                            name: channelName,
                            type: ChannelType.GuildText,
                            permissionOverwrites: [
                                { 
                                    id: guild.id, 
                                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] 
                                }
                            ],
                        });
                        console.log(`✅ تم إنشاء القناة الدائمة: ${channel.name}`);
                    } catch (error) {
                        console.error(`❌ خطأ في إنشاء القناة الدائمة: ${error.message}`);
                    }
                } else {
                    console.log(`✅ القناة الدائمة موجودة بالفعل: ${channel.name}`);
                }
            });
        });
    }
};
