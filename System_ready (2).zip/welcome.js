const { EmbedBuilder } = require('discord.js');
require('dotenv').config();

const welcomeChannelId = process.env.WELCOME; 

module.exports = {
    name: 'welcomeSystem',
    execute(client) {
        client.on('guildMemberAdd', async (member) => {
            const welcomeChannel = member.guild.channels.cache.get(welcomeChannelId);
            if (!welcomeChannel) return console.error('❌ Welcome channel is missing or incorrect');

            const serverName = member.guild.name;
            const serverIcon = member.guild.iconURL({ dynamic: true, size: 1024 }) || '';
            const memberCount = member.guild.memberCount;
            const userAvatar = member.user.displayAvatarURL({ dynamic: true, size: 512 });

            const welcomeMessage = `👋 مرحبًا بك يا <@${member.user.id}> في **${serverName}**!`;

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setDescription(`✨ نورتنا يا غالي بانضمامك إلى **${serverName}**!\n🎉 بسببك وصلنا إلى **${memberCount}** عضو!`)
                .setThumbnail(userAvatar)
                .setFooter({ text: `${serverName}`, iconURL: serverIcon });

            welcomeChannel.send({ content: welcomeMessage, embeds: [embed] });
        });
    }
};
