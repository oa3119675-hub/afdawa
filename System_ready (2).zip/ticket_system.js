const { ChannelType, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionsBitField, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { recordTicketCreated, recordTicketClosed } = require('./ticket_analytics');

const activeTickets = new Set();
const ticketStore = new Map(); // key: channelId, value: { userId, ticketId, status, admin, createdAt }
const dataPath = path.join(__dirname, 'data', 'tickets.json');

function loadTickets() {
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, JSON.stringify({ ticketCount: 1, tickets: {} }, null, 2));
    }
    return JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
}

function saveTickets(data) {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
}

function getTicket(channelId) {
    return ticketStore.get(channelId);
}

function setTicket(channelId, data) {
    ticketStore.set(channelId, data);
}

function deleteTicket(channelId) {
    ticketStore.delete(channelId);
}

module.exports = {
    name: 'ticketSystem',
    execute(client) {
        client.on('ready', async () => {
            console.log('System Ticket ✅');

            const channel = client.channels.cache.get(process.env.CHANNEL_ID);
            if (!channel) return console.error(`❌ لم يتم العثور على القناة: ${process.env.CHANNEL_ID}`);

            const embed = new EmbedBuilder()
                .setColor(0x00AE86)
                .setTitle('🎟️ فتح التذاكر')
                .setDescription('يرجى اختيار نوع التذكرة من القائمة أدناه')
                .setImage(process.env.BANNER_URL)
                .setThumbnail(process.env.THUMBNAIL_URL)
                .setFooter({ text: 'System Tickets' });

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('select_ticket_type')
                    .setPlaceholder('اختر نوع التذكرة')
                    .addOptions([
                        { label: 'شراء', value: 'ticket_purchase', description: 'للطلبات والشراء' },
                        { label: 'جرفكس', value: 'ticket_graphics', description: 'لطلبات الجرافيكس والتصميم' },
                        { label: 'دعم فني', value: 'ticket_support', description: 'لحل المشاكل والدعم' }
                    ])
            );

            await channel.send({ embeds: [embed], components: [selectMenu] }).catch(console.error);
        });

        client.on('interactionCreate', async (interaction) => {
            // Handle ticket type selection
            if (interaction.isStringSelectMenu() && interaction.customId === 'select_ticket_type') {
                const { user, guild, values } = interaction;
                
                // Check if bot is restricted to owner only
                if (process.env.OWNER_ID && user.id !== process.env.OWNER_ID) {
                    return interaction.reply({ content: '❌ هذا البوت خاص وليس متاح للجميع', ephemeral: true });
                }

                if (activeTickets.has(user.id)) {
                    return interaction.reply({ content: '❌ لديك بالفعل تذكرة مفتوحة!', ephemeral: true });
                }

                // Show rules before proceeding
                const rulesEmbed = new EmbedBuilder()
                    .setColor(0x00ffff)
                    .setTitle('📜 قوانين التذاكر')
                    .setDescription(`مرحباً بك! قبل فتح التذكرة، يرجى الالتزام بالقوانين التالية:

1️⃣ **عدم البريد العشوائي** - لا تبعث رسائل مزعجة أو سبام
2️⃣ **استخدام محدود** - استخدم التذكرة لطلب الدعم فقط
3️⃣ **الاحترام** - يرجى احترام جميع أعضاء الطاقم
4️⃣ **المعلومات الصحيحة** - قدم معلومات دقيقة عن مشكلتك
5️⃣ **الصبر** - سيرد عليك الطاقم في أقرب وقت ممكن

🔒 بالموافقة على هذه القوانين، فأنت توافق على اتباعها بالكامل.`);

                const acceptButtons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`accept_rules_${values[0]}`)
                        .setLabel('✅ أقبل القوانين')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('decline_rules')
                        .setLabel('❌ رفض')
                        .setStyle(ButtonStyle.Danger)
                );

                return interaction.reply({ embeds: [rulesEmbed], components: [acceptButtons], ephemeral: true });
            }

            // Handle rules acceptance - Create ticket directly
            if (interaction.isButton() && interaction.customId.startsWith('accept_rules_')) {
                const { user, guild } = interaction;
                const ticketType = interaction.customId.replace('accept_rules_', '');

                if (activeTickets.has(user.id)) {
                    return interaction.reply({ content: '❌ لديك بالفعل تذكرة مفتوحة!', ephemeral: true });
                }

                let categoryId;
                if (ticketType === 'ticket_purchase') categoryId = process.env.CATEGORY_PURCHASE;
                if (ticketType === 'ticket_graphics') categoryId = process.env.CATEGORY_GRAPHICS;
                if (ticketType === 'ticket_support') categoryId = process.env.CATEGORY_SUPPORT;

                if (!categoryId) return interaction.reply({ content: '❌ خطأ في النظام.', ephemeral: true });

                // Load and increment ticket count
                const ticketData = loadTickets();
                const ticketId = ticketData.ticketCount++;

                ticketData.tickets[ticketId] = { 
                    userId: user.id, 
                    userName: user.username,
                    createdAt: new Date().toISOString(),
                    status: 'غير مستلم',
                    admin: null
                };
                saveTickets(ticketData);
                
                // Record ticket creation in analytics
                recordTicketCreated();

                const ticketChannel = await guild.channels.create({
                    name: `#${ticketId}・تذكرة・غير مستلمه`,
                    type: ChannelType.GuildText,
                    parent: categoryId,
                    permissionOverwrites: [
                        { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                        { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
                    ]
                });

                activeTickets.add(user.id);

                // Store in memory for fast access
                setTicket(ticketChannel.id, {
                    userId: user.id,
                    number: ticketId,
                    status: 'غير مستلم'
                });

                // Send ticket embed
                const ticketEmbed = new EmbedBuilder()
                    .setColor(0x00AE86)
                    .setTitle(`🎫 تذكرة #${ticketId}`)
                    .setDescription('يرجى توضيح مشكلتك وسيرد عليك الطاقم قريبًا.')
                    .addFields([
                        { name: '**المشرف:**', value: 'لم يتم الاستلام بعد', inline: true },
                        { name: '**الحالة:**', value: 'غير مستلم', inline: true }
                    ])
                    .setFooter({ text: `Ticket ID: ${ticketId}` });

                const ticketButtons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('lock_ticket')
                        .setLabel('🔒 قفل التذكرة')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('claim_ticket')
                        .setLabel('✅ استلام التذكرة')
                        .setStyle(ButtonStyle.Success)
                );

                await ticketChannel.send({
                    content: `السلام عليكم، سيتم الرد عليك في أقرب فترة.`
                });

                const statusMsg = await ticketChannel.send({
                    embeds: [ticketEmbed],
                    components: [ticketButtons]
                });

                // Store message ID for later updates
                ticketData.tickets[ticketId].statusMessageId = statusMsg.id;
                saveTickets(ticketData);

                interaction.reply({ content: `✅ تم فتح تذكرتك: ${ticketChannel}`, ephemeral: true });
                return;
            }

            // Handle rules rejection
            if (interaction.isButton() && interaction.customId === 'decline_rules') {
                return interaction.reply({ content: '❌ تم رفض القوانين. لا يمكنك فتح تذكرة بدون قبول القوانين.', ephemeral: true });
            }

            if (!interaction.isButton()) return;

            // Lock Ticket Button
            if (interaction.customId === 'lock_ticket') {
                const memberRoleId = process.env.MEMBER_ROLE;
                const logChannelId = process.env.LOG_CHANNEL;
                
                if (!memberRoleId || !interaction.member.roles.cache.has(memberRoleId)) {
                    return interaction.reply({ content: '❌ أنت ما عندك صلاحية قفل هذه التذكرة!', ephemeral: true });
                }

                try {
                    await interaction.channel.permissionOverwrites.edit(interaction.guild.id, {
                        SendMessages: false
                    });

                    // تسجيل قفل التذكرة
                    if (logChannelId) {
                        const logChannel = interaction.guild.channels.cache.get(logChannelId);
                        if (logChannel) {
                            await logChannel.send(`🔒 **تم قفل التذكرة:** ${interaction.channel.name} بواسطة ${interaction.user.tag}`);
                        }
                    }

                    // Show reopen/delete options with dynamic button IDs
                    const closedEmbed = new EmbedBuilder()
                        .setTitle('🔒 تم قفل التذكرة')
                        .setColor(0xFF0000)
                        .setDescription('يمكنك الآن اختيار فتح التذكرة أو حذفها بالكامل. 👇');

                    const closedButtons = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`reopen_${interaction.channel.id}`)
                            .setLabel('🔓 فتح التذكرة')
                            .setStyle(ButtonStyle.Success),
                        new ButtonBuilder()
                            .setCustomId(`delete_${interaction.channel.id}`)
                            .setLabel('🗑️ حذف التذكرة')
                            .setStyle(ButtonStyle.Danger)
                    );

                    await interaction.reply({ content: '🔒 تم قفل التذكرة بنجاح!' });
                    await interaction.channel.send({ embeds: [closedEmbed], components: [closedButtons] });
                } catch (error) {
                    console.error('❌ خطأ في قفل التذكرة:', error.message);
                    interaction.reply({ content: '❌ حدث خطأ أثناء قفل التذكرة!', ephemeral: true });
                }
                return;
            }

            // Reopen Ticket Button (Dynamic ID)
            if (interaction.customId.startsWith('reopen_')) {
                const memberRoleId = process.env.MEMBER_ROLE;
                const logChannelId = process.env.LOG_CHANNEL;
                
                if (!memberRoleId || !interaction.member.roles.cache.has(memberRoleId)) {
                    return interaction.reply({ content: '❌ أنت ما عندك صلاحية فتح هذه التذكرة!', ephemeral: true });
                }

                try {
                    const channelId = interaction.customId.split('_')[1];
                    const ticketData = getTicket(channelId);
                    
                    if (!ticketData) {
                        return interaction.reply({ content: '❌ بيانات التذكرة غير موجودة!', ephemeral: true });
                    }

                    const guild = interaction.guild;
                    const oldChannel = guild.channels.cache.get(channelId);

                    if (!oldChannel) {
                        // إذا القناة تم حذفها، أعيد إنشاءها
                        const newChannel = await guild.channels.create({
                            name: `#${ticketData.number}・تذكرة・غير مستلمه`,
                            type: ChannelType.GuildText,
                            parent: process.env.CATEGORY_PURCHASE,
                            permissionOverwrites: [
                                { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                                { id: ticketData.userId, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
                            ]
                        });
                        
                        setTicket(newChannel.id, ticketData);
                        deleteTicket(channelId);
                        
                        // Log reopen action
                        if (logChannelId) {
                            const logChannel = guild.channels.cache.get(logChannelId);
                            if (logChannel) {
                                await logChannel.send(`🔓 **تم إعادة فتح التذكرة:** ${newChannel.name} بواسطة ${interaction.user.tag}`);
                            }
                        }
                        
                        return interaction.reply({ content: '✅ تم إعادة فتح التذكرة بنجاح!', ephemeral: true });
                    }

                    // إذا القناة موجودة فقط افتحها مجددًا
                    await oldChannel.permissionOverwrites.edit(guild.id, {
                        SendMessages: true
                    });

                    // Log reopen action
                    if (logChannelId) {
                        const logChannel = guild.channels.cache.get(logChannelId);
                        if (logChannel) {
                            await logChannel.send(`🔓 **تم فتح التذكرة:** ${oldChannel.name} بواسطة ${interaction.user.tag}`);
                        }
                    }

                    await interaction.reply({ content: '✅ تم فتح التذكرة بنجاح!' });
                    await interaction.message.delete().catch(() => {});
                } catch (error) {
                    console.error('❌ خطأ في فتح التذكرة:', error.message);
                    interaction.reply({ content: '❌ حدث خطأ أثناء فتح التذكرة!', ephemeral: true });
                }
                return;
            }

            // Delete Ticket Button (Dynamic ID)
            if (interaction.customId.startsWith('delete_')) {
                const memberRoleId = process.env.MEMBER_ROLE;
                const logChannelId = process.env.LOG_CHANNEL;
                
                if (!memberRoleId || !interaction.member.roles.cache.has(memberRoleId)) {
                    return interaction.reply({ content: '❌ أنت ما عندك صلاحية حذف هذه التذكرة!', ephemeral: true });
                }

                try {
                    const channelId = interaction.customId.split('_')[1];
                    const delChannel = interaction.guild.channels.cache.get(channelId);
                    
                    // Log delete action
                    if (logChannelId) {
                        const logChannel = interaction.guild.channels.cache.get(logChannelId);
                        if (logChannel) {
                            const channelName = delChannel ? delChannel.name : `تذكرة | 🎫 | ${channelId}`;
                            await logChannel.send(`🗑️ **تم حذف التذكرة:** ${channelName} بواسطة ${interaction.user.tag}`);
                        }
                    }

                    // Remove from memory store
                    deleteTicket(channelId);

                    await interaction.reply({ content: '🗑️ يتم حذف التذكرة...' });
                    
                    if (delChannel) {
                        setTimeout(async () => {
                            try {
                                await delChannel.delete();
                            } catch (error) {
                                console.error('❌ فشل في حذف التذكرة:', error.message);
                            }
                        }, 1500);
                    }
                } catch (error) {
                    console.error('❌ خطأ في حذف التذكرة:', error.message);
                    interaction.reply({ content: '❌ حدث خطأ أثناء حذف التذكرة!', ephemeral: true });
                }
                return;
            }

            // Claim/Unclaim Ticket Button (Toggle)
            if (interaction.customId === 'claim_ticket') {
                const memberRoleId = process.env.MEMBER_ROLE;
                const channel = interaction.channel;
                const logChannelId = process.env.LOG_CHANNEL;
                
                if (!memberRoleId || !interaction.member.roles.cache.has(memberRoleId)) {
                    return interaction.reply({ content: '❌ أنت ما عندك صلاحية استلام هذه التذكرة!', ephemeral: true });
                }

                try {
                    // Get current status from embed
                    const embed = interaction.message.embeds[0];
                    const isClaimed = embed.data.fields.some(field => field.value === '✅ مستلم');

                    // Get ticket from memory store
                    const ticket = getTicket(interaction.channel.id);
                    if (!ticket) {
                        return interaction.reply({ content: '❌ تعذر العثور على بيانات التذكرة!', ephemeral: true });
                    }
                    
                    const ticketId = ticket.number;

                    // Toggle claim status
                    const newStatus = !isClaimed;
                    
                    if (newStatus) {
                        // Claiming the ticket
                        await channel.permissionOverwrites.edit(interaction.member.id, {
                            SendMessages: true,
                            ViewChannel: true
                        });
                        
                        await channel.setName(`#${ticketId}・تذكرة・مستلم`);
                        
                        // Update in memory
                        ticket.status = 'مستلم';
                        setTicket(channel.id, ticket);

                        // Log claim action
                        if (logChannelId) {
                            const logChannel = interaction.guild.channels.cache.get(logChannelId);
                            if (logChannel) {
                                await logChannel.send(`✅ **تم استلام التذكرة:** ${channel.name} بواسطة ${interaction.user.tag}`);
                            }
                        }

                        await interaction.reply({ content: `✅ تم استلام التذكرة بواسطة ${interaction.user.tag}`, ephemeral: true });
                    } else {
                        // Unclaiming the ticket
                        await channel.setName(`#${ticketId}・تذكرة・غير مستلمه`);
                        
                        // Update in memory
                        ticket.status = 'غير مستلم';
                        setTicket(channel.id, ticket);

                        // Log unclaim action
                        if (logChannelId) {
                            const logChannel = interaction.guild.channels.cache.get(logChannelId);
                            if (logChannel) {
                                await logChannel.send(`❌ **تم إلغاء استلام التذكرة:** ${channel.name} بواسطة ${interaction.user.tag}`);
                            }
                        }

                        await interaction.reply({ content: `✅ تم إلغاء استلام التذكرة`, ephemeral: true });
                    }

                    // Update the embed and buttons
                    const updatedEmbed = new EmbedBuilder()
                        .setColor(0x00AE86)
                        .setTitle(`🎫 تذكرة #${ticketId}`)
                        .setDescription('يرجى توضيح مشكلتك وسيرد عليك الطاقم قريبًا.')
                        .addFields([
                            { name: '**المشرف:**', value: newStatus ? interaction.user.tag : 'لم يتم الاستلام بعد', inline: true },
                            { name: '**الحالة:**', value: newStatus ? '✅ مستلم' : 'غير مستلم', inline: true }
                        ])
                        .setFooter({ text: `Ticket ID: ${ticketId}` });

                    const updatedButtons = new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId('lock_ticket')
                            .setLabel('🔒 قفل التذكرة')
                            .setStyle(ButtonStyle.Danger),
                        new ButtonBuilder()
                            .setCustomId('claim_ticket')
                            .setLabel(newStatus ? '❌ إلغاء الاستلام' : '✅ استلام التذكرة')
                            .setStyle(newStatus ? ButtonStyle.Secondary : ButtonStyle.Success)
                    );

                    await interaction.message.edit({ embeds: [updatedEmbed], components: [updatedButtons] });
                } catch (error) {
                    console.error('❌ خطأ في استلام/إلغاء استلام التذكرة:', error.message);
                    interaction.reply({ content: '❌ حدث خطأ أثناء معالجة الطلب!', ephemeral: true });
                }
                return;
            }

            // Close Ticket Button
            if (interaction.customId === 'close_ticket') {
                const { channel, user } = interaction;
        
                if (!activeTickets.has(user.id)) {
                    return interaction.reply({ content: '❌ لا يمكنك إغلاق هذه التذكرة!', ephemeral: true });
                }
        
                await interaction.deferUpdate();
                await interaction.followUp({ content: '🔒 يتم إغلاق التذكرة...', ephemeral: false });
        
                activeTickets.delete(user.id);
        
                setTimeout(async () => {
                    if (channel && channel.deletable) {
                        try {
                            await channel.delete();
                        } catch (error) {
                            console.error('❌ فشل في حذف القناة:', error);
                        }
                    }
                }, 2000);
            }

            // Restart Bot Button (Admin Only)
            if (interaction.customId === 'restart_bot') {
                const { PermissionFlagsBits } = require('discord.js');
                
                if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                    return interaction.reply({ content: '❌ ليس لديك صلاحيات لإعادة تشغيل البوت', ephemeral: true });
                }

                await interaction.reply({ content: '🔄 جاري إعادة تشغيل البوت...', ephemeral: true });
                console.log(`🔄 Bot is restarting by button click from ${interaction.user.tag}...`);
                
                setTimeout(() => {
                    process.exit(0);
                }, 1000);
            }
        });
        
    }
};
