// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const dotenv = require('dotenv');
dotenv.config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lock')
        .setDescription('Locks a channel to prevent messages.')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('The channel to lock')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels), 

    async execute(client, interaction) {
        const channel = interaction.options.getChannel('channel');
        const adminRole = process.env.ADMIN;
        const logChannel = client.channels.cache.get(process.env.LOG_THREAD_LOCK);

        if (!interaction.member.roles.cache.has(adminRole)) {
            return interaction.reply({ content: '❌ ليس لديك الإذن لاستخدام هذا الأمر', ephemeral: true });
        }

        await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SendMessages: false });

        // إنشاء لوغ احترافي
        const embed = new EmbedBuilder()
            .setTitle('Channel Locked')
            .setDescription(`**Channel:** ${channel} has been locked by ${interaction.user}.`)
            .setColor(0xFF0000)
            .setTimestamp();

        if (logChannel) logChannel.send({ embeds: [embed] });

        interaction.reply({ content: `✅ Locked ${channel}.`, ephemeral: false });
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj