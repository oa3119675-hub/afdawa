const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slowmod')
        .setDescription('تفعيل وضع البطء في قناة معينة')
        .addIntegerOption(option => 
            option.setName('time')
                .setDescription('المدة بالثواني (0 لتعطيل وضع البطء)')
                .setRequired(true)
        )
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('القناة المستهدفة')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });

            // جلب معرف رتبة ADMIN من .env
            const adminRoleId = process.env.ADMIN;
            if (!adminRoleId) {
                return interaction.editReply({ content: '❌ لم يتم تحديد معرف رتبة ADMIN في الإعدادات.', ephemeral: true });
            }

            // التحقق مما إذا كان المستخدم يمتلك رتبة ADMIN
            if (!interaction.member.roles.cache.has(adminRoleId)) {
                return interaction.editReply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر. يجب أن تمتلك رتبة ADMIN.', ephemeral: true });
            }

            const time = interaction.options.getInteger('time');
            const channel = interaction.options.getChannel('channel');

            // التحقق من أن القناة تدعم وضع البطء
            if (!channel.isTextBased()) {
                return interaction.editReply({ content: '❌ لا يمكن تطبيق وضع البطء على هذه القناة.', ephemeral: true });
            }

            // تحديد الحد الأقصى (6 ساعات = 21600 ثانية)
            if (time < 0 || time > 21600) {
                return interaction.editReply({ content: '⚠️ الحد الأقصى لوضع البطء هو **6 ساعات (21600 ثانية)**.', ephemeral: true });
            }

            // تطبيق وضع البطء
            await channel.setRateLimitPerUser(time);
            const status = time === 0 ? 'تم **تعطيل** وضع البطء' : `تم تفعيل وضع البطء لمدة **${time} ثانية**`;

            await interaction.editReply({ content: `✅ ${status} في القناة ${channel}.`, ephemeral: false });

        } catch (error) {
            console.error('❌ خطأ أثناء تغيير وضع البطء:', error);
            interaction.editReply({ content: '❌ حدث خطأ أثناء محاولة ضبط وضع البطء.', ephemeral: true });
        }
    }
};