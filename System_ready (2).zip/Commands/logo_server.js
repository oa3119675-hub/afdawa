// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('server_logo')
        .setDescription('عرض صورة بروفايل السيرفر'),

    async execute(client, interaction) {
        const guild = interaction.guild;

        if (!guild.iconURL()) {
            return interaction.reply({
                content: '❌ هذا السيرفر لا يحتوي على صورة بروفايل.',
                ephemeral: true,
            });
        }

        const serverLogoEmbed = new EmbedBuilder()
            .setColor('Random')
            .setTitle('🖼️ صورة بروفايل السيرفر')
            .setDescription(`[رابط الصورة الأصلية](${guild.iconURL({ dynamic: true, size: 1024 })})`)
            .setImage(guild.iconURL({ dynamic: true, size: 1024 }))
            .setFooter({
                text: `By ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
            })
            .setTimestamp();

        await interaction.reply({ embeds: [serverLogoEmbed] });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj