// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, Colors } = require('discord.js');
require('dotenv').config();

const ALLOWED_USED_KICK = process.env.OWNER.split(',');
const KICK_LOG = process.env.KICK_LOG;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('حظر مستخدم معين من الخادم.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد حظره.')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('time')
                .setDescription('مدة الحظر بالدقائق (0 = دائم).')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الحظر.')
                .setRequired(false)),

    async execute(client, interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetUser = interaction.options.getMember('user');
        const banTime = interaction.options.getInteger('time');
        const reason = interaction.options.getString('reason') || 'لم يتم تحديد السبب.';

        if (!targetUser) {
            return interaction.editReply({ content: '❌ لا يمكن العثور على هذا المستخدم في السيرفر.' });
        }

        const hasAllowedRole = interaction.member.roles.cache.some(role => ALLOWED_USED_KICK.includes(role.id));
        if (!hasAllowedRole) {
            return interaction.editReply({ content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.' });
        }

        if (!targetUser.bannable) {
            return interaction.editReply({ content: '❌ لا يمكنني حظر هذا المستخدم. تأكد من أن رتبتي أعلى من رتبته.' });
        }

        try {
            await targetUser.ban({ reason });
            await interaction.editReply({ content: `✅ تم حظر ${targetUser} بنجاح.\n**المدة:** ${banTime} دقيقة\n**السبب:** ${reason}` });

            const logChannel = client.channels.cache.get(KICK_LOG);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 حظر عضو 🚨')
                    .setColor(Colors.DarkRed)
                    .addFields(
                        { name: '👤 العضو المحظور', value: `${targetUser.user.tag} (${targetUser.id})`, inline: false },
                        { name: '🛠 تم الحظر بواسطة', value: `${interaction.user.tag} (${interaction.user.id})`, inline: false },
                        { name: '⏳ المدة', value: banTime === 0 ? 'دائم' : `${banTime} دقيقة`, inline: false },
                        { name: '📄 السبب', value: reason, inline: false }
                    )
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }

            if (banTime > 0) {
                setTimeout(async () => {
                    try {
                        await interaction.guild.members.unban(targetUser.id);
                        if (logChannel) {
                            const unbanEmbed = new EmbedBuilder()
                                .setTitle('✅ إلغاء الحظر')
                                .setColor(Colors.Green)
                                .addFields(
                                    { name: '👤 العضو', value: `${targetUser.user.tag} (${targetUser.id})`, inline: false },
                                    { name: '⏳ انتهت مدة الحظر', value: `${banTime} دقيقة`, inline: false }
                                )
                                .setTimestamp();

                            await logChannel.send({ embeds: [unbanEmbed] });
                        }
                    } catch (err) {
                        console.error('❌ Unblocking Error:', err);
                    }
                }, banTime * 60 * 1000);
            }
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: '❌ حدث خطأ أثناء محاولة حظر المستخدم.' });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj