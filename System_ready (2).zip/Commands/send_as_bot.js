// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sendasbot')
        .setDescription('إرسال رسالة بصوت البوت.')
        .addStringOption(option =>
            option.setName('msg')
                .setDescription('الرسالة التي تريد إرسالها')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reply')
                .setDescription('معرّف الرسالة التي تريد الرد عليها (اختياري)')
                .setRequired(false)
        ),
    async execute(client, interaction) {
        const allowedRoleId = process.env.STAFF;
        const logThreadId = process.env.LOG_SEND_AS_BOT;

        if (!interaction.member.roles.cache.has(allowedRoleId)) {
            return interaction.reply({
                content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.',
                ephemeral: true,
            });
        }

        const messageContent = interaction.options.getString('msg');
        const replyMessageId = interaction.options.getString('reply');

        try {
            let sentMessage;

            if (replyMessageId) {
                const targetMessage = await interaction.channel.messages.fetch(replyMessageId).catch(() => null);

                if (!targetMessage) {
                    return interaction.reply({
                        content: '❌ لم يتم العثور على الرسالة للرد عليها. يرجى التحقق من معرف الرسالة.',
                        ephemeral: true,
                    });
                }

                sentMessage = await targetMessage.reply(messageContent);
            } else {
                sentMessage = await interaction.channel.send(messageContent);
            }

            const logEmbed = new EmbedBuilder()
                .setTitle('🔹 سجل تنفيذ الأمر: /sendasbot')
                .setColor(Colors.Blue)
                .addFields(
                    { name: '👤 تم التنفيذ بواسطة', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '📢 القناة', value: `${interaction.channel} (${interaction.channel.name})`, inline: true },
                    { name: '📝 الرسالة', value: `\`\`\`${messageContent}\`\`\`` },
                    { name: '📩 الرد على', value: replyMessageId ? `معرّف الرسالة: ${replyMessageId}` : 'لا يوجد', inline: false },
                    { name: '📅 التاريخ', value: new Date().toLocaleString('ar-EG', { timeZone: 'UTC' }), inline: false }
                )
                .setTimestamp();

            const logThread = client.channels.cache.get(logThreadId);
            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            } else {
                console.warn('[Warning] Log thread not found or not a thread!');
            }

            await interaction.reply({ content: '✅ تم إرسال الرسالة وتسجيلها!', ephemeral: true });
        } catch (error) {
            console.error(`[Error] Failed to execute /sendasbot command:`, error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء تنفيذ الأمر.',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj