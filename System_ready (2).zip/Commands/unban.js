// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, Colors } = require('discord.js');
require('dotenv').config();

const ALLOWED_USED_KICK = process.env.OWNER.split(',');
const KICK_LOG = process.env.KICK_LOG;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('إلغاء الحظر عن مستخدم معين.')
        .addStringOption(option =>
            option.setName('user')
                .setDescription('معرف المستخدم الذي تريد إلغاء حظره.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب إلغاء الحظر.')
                .setRequired(false)),

    async execute(client, interaction) {
        await interaction.deferReply({ ephemeral: true });

        const userId = interaction.options.getString('user');
        const reason = interaction.options.getString('reason') || 'لم يتم تحديد السبب.';

        const hasAllowedRole = interaction.member.roles.cache.some(role => ALLOWED_USED_KICK.includes(role.id));
        if (!hasAllowedRole) {
            return interaction.editReply({ content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.' });
        }

        try {
            const bannedUsers = await interaction.guild.bans.fetch();
            const bannedUser = bannedUsers.get(userId);

            if (!bannedUser) {
                return interaction.editReply({ content: '❌ هذا المستخدم غير محظور حاليًا.' });
            }

            await interaction.guild.members.unban(userId, reason);
            await interaction.editReply({ content: `✅ تم إلغاء الحظر عن <@${userId}> بنجاح.\n**السبب:** ${reason}` });

            const logChannel = client.channels.cache.get(KICK_LOG);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('✅ إلغاء حظر عضو')
                    .setColor(Colors.Green)
                    .addFields(
                        { name: '👤 العضو', value: `<@${userId}> (${userId})`, inline: false },
                        { name: '🛠 تم إلغاء الحظر بواسطة', value: `${interaction.user.tag} (${interaction.user.id})`, inline: false },
                        { name: '📄 السبب', value: reason, inline: false }
                    )
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: '❌ حدث خطأ أثناء محاولة إلغاء الحظر.' });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj