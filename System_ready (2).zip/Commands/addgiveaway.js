// Code Nexus => https://discord.gg/Tpwgkj9gzj
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add_giveaway')
        .setDescription('انشأ مسابقة جديدة')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('عنوان المعلن')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('مدة العرض الترويجي (على سبيل المثال، 6 ساعات، أو يومين، أو 30 دقيقة)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('عدد الفائزين')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('تحديد الجائزة')
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('القناة التي سيتم نشر الغيفواي عليها')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('host')
                .setDescription('المسؤول عن غيفواي الحالية'))
        .addStringOption(option =>
            option.setName('banner')
                .setDescription('عنوان رابط لصورة الشعار (اختياري)'))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('عنوان رابط للصورة المصغرة (اختياري)')),

    async execute(client, interaction) {
        const allowedRoleIds = process.env.ADMIN.split(',');

        const memberRoles = interaction.member.roles.cache;
        const hasPermission = allowedRoleIds.some(roleId => memberRoles.has(roleId));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ ليس لديك الإذن لاستخدام هذا الأمر.',
                ephemeral: false,
            });
        }

        const name = interaction.options.getString('name');
        const duration = interaction.options.getString('duration');
        const winners = interaction.options.getInteger('winners');
        const prize = interaction.options.getString('prize');
        const channel = interaction.options.getChannel('channel');
        const host = interaction.options.getUser('host');
        const banner = interaction.options.getString('banner');
        const thumbnail = interaction.options.getString('thumbnail');

        const durationMs = parseDuration(duration);
        if (durationMs === null) {
            return await interaction.reply({ content: '❌ تنسيق المدة غير صالح. يُرجى استخدام "h" أو "d" أو "m" (على سبيل المثال، 6h، 2d، 30m).', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle(`🎉 Giveaway: ${name}`)
            .setDescription(`
                **Prize:** ${prize}
                **Winners:** ${winners}
                **Ends In:** <t:${Math.floor((Date.now() + durationMs) / 1000)}:R>
                **Hosted By:** ${host ? host : 'Anonymous'}
            `)
            .setColor('Blue')
            .setFooter({ text: 'اضغط على الزر اسفله للمشاركة في الغيفواي' });

        if (banner) embed.setImage(banner);
        if (thumbnail) embed.setThumbnail(thumbnail);

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_enter')
                    .setLabel('🎉 شارك')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('giveaway_participants')
                    .setLabel('📋 عدد المشاركين')
                    .setStyle(ButtonStyle.Secondary)
            );

        try {
            const giveawayMessage = await channel.send({ embeds: [embed], components: [button] });

            const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
            const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

            const giveawayEntry = {
                id: giveawayMessage.id,
                participants: [],
                active: true,
                prize,
                winners,
                durationMs,
                channelId: channel.id,
                hostId: host ? host.id : null
            };

            giveawayData.push(giveawayEntry);
            fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

            await interaction.reply({
                content: `✅ تم إنشاء المسابقة بنجاح في القناة: ${channel.name}!`,
                ephemeral: true,
            });

            const collector = giveawayMessage.createMessageComponentCollector({ time: durationMs });

collector.on('collect', async (interaction) => {
    if (interaction.customId === 'giveaway_enter') {
        const user = interaction.user;
        
        // التحقق مما إذا كان المستخدم قد اشترك بالفعل
        if (giveawayEntry.participants.some(p => p.id === user.id)) {
            return await interaction.reply({ content: '❌ لقد تم تسجيلك بالفعل!', ephemeral: true });
        }

        // إضافة المستخدم إلى قائمة المشاركين
        giveawayEntry.participants.push({ username: user.username, id: user.id });
        fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

        // استخدام deferReply() ثم editReply() بدلاً من reply()
        await interaction.deferReply({ ephemeral: true });
        await interaction.editReply({ content: '🎉 لقد تم مشاركتك بنجاح!' });
    
    } else if (interaction.customId === 'giveaway_participants') {
        await interaction.deferReply({ ephemeral: true });
        await interaction.editReply({ content: `📋 عدد المشاركين: ${giveawayEntry.participants.length}` });
    }
});


            collector.on('end', async () => {
                try {
                    const giveawayMessage = await channel.messages.fetch(giveawayEntry.id);
                    if (!giveawayMessage) {
                        throw new Error("Message not found");
                    }
                    await giveawayMessage.edit({ components: [] });
            
                    const selectedWinners = getRandomWinners(giveawayEntry.participants, winners);
            
                    const winnerMentions = selectedWinners.map(winner => `<@${winner.id}>`).join(', ');
                    await channel.send(`🎉 **انتهت المسابقة!** 🎉\nالفائزون هم: ${winnerMentions}`);
            
                    for (const winner of selectedWinners) {
                        try {
                            const user = await client.users.fetch(winner.id);
                            await user.send({
                                content: `🎉 مبروك لقد فزت بالجائزة!\n**Prize:** ${prize}\n\nتحقق من الفائزين: ${giveawayMessage.url}`,
                            });
                        } catch (error) {
                            console.log(`Couldn't DM winner ${winner.id}`);
                        }
                    }
            
                    if (host) {
                        try {
                            const hostUser = await client.users.fetch(host.id);
                            await hostUser.send({
                                content: `⏰ انتهت المسابقة التي قمت باستضافتها. يرجى التحقق من الفائزين والتأكد من معالجة كل شيء. ${giveawayMessage.url}`,
                            });
                        } catch (error) {
                            console.log(`Couldn't DM host ${host.id}`);
                        }
                    }
                } catch (error) {
                    console.log('❌ Failed to edit giveaway message or handle giveaway end:', error);
                }
            });            
        } catch (error) {
            console.error('❌ Failed to create giveaway:', error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء إنشاء المسابقة. يرجى المحاولة مرة أخرى.',
                ephemeral: true,
            });
        }

        client.on('messageDelete', async (message) => {
            try {
                const giveawayData = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'addgiveaway.json'), 'utf-8'));
                const giveaway = giveawayData.find(g => g.id === message.id);
                if (giveaway) {
                    giveaway.active = false;
                    fs.writeFileSync(path.join(__dirname, 'data', 'addgiveaway.json'), JSON.stringify(giveawayData, null, 2));
                    console.log(`Giveaway with ID ${giveaway.id} has been deactivated due to message deletion.`);
                }
            } catch (error) {
                console.log('❌ Error handling giveaway deletion:', error);
            }
        });
    }
};

function parseDuration(duration) {
    const regex = /^(\d+)(h|d|m)$/;
    const match = duration.match(regex);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit = match[2];
    switch (unit) {
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        case 'm': return value * 60 * 1000;
        default: return null;
    }
}

function getRandomWinners(participants, winnersCount) {
    const shuffled = participants.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, winnersCount);
}

// Code Nexus => https://discord.gg/Tpwgkj9gzj