// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs');
const path = require('path');

const afkFilePath = path.join(__dirname, 'data', 'afk.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('afk')
        .setDescription('تعيين حالة AFK مع سبب.')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الغياب')
                .setRequired(false)
        ),
    async execute(client, interaction) {
        const userId = interaction.user.id;
        const reason = interaction.options.getString('reason');

        if (!fs.existsSync(afkFilePath)) {
            try {
                fs.writeFileSync(afkFilePath, JSON.stringify({}, null, 2));
            } catch (err) {
                console.error('❌ Error creating afk file:', err);
                return interaction.reply('❌ حدث خطأ أثناء إنشاء ملف AFK.');
            }
        }

        let afkData = {};
        try {
            afkData = JSON.parse(fs.readFileSync(afkFilePath, 'utf8'));
        } catch (err) {
            console.error('❌ Error reading afk file:', err);
        }

        if (reason) {
            afkData[userId] = { reason: reason, time: Date.now() };
            try {
                fs.writeFileSync(afkFilePath, JSON.stringify(afkData, null, 2));
                return interaction.reply(`تم تعيينك في حالة AFK بسبب: ${reason}`);
            } catch (err) {
                console.error('❌ Error saving afk file:', err);
                return interaction.reply('❌ حدث خطأ أثناء حفظ بيانات AFK.');
            }
        } else {
            if (afkData[userId]) {
                delete afkData[userId];
                try {
                    fs.writeFileSync(afkFilePath, JSON.stringify(afkData, null, 2));
                    return interaction.reply('تم إلغاء حالة AFK الخاصة بك. أهلاً بعودتك!');
                } catch (err) {
                    console.error('❌ Error saving afk file:', err);
                    return interaction.reply('❌ حدث خطأ أثناء حفظ بيانات AFK.');
                }
            } else {
                return interaction.reply('أنت لست في حالة AFK.');
            }
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj