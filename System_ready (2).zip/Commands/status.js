// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors, ActivityType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('status')
        .setDescription('تغيير حالة البوت')
        .addStringOption(option =>
            option.setName('state')
                .setDescription('اختر حالة البوت')
                .setRequired(true)
                .addChoices(
                    { name: 'Online', value: 'online' },
                    { name: 'Idle', value: 'idle' },
                    { name: 'Do Not Disturb', value: 'dnd' },
                    { name: 'Offline', value: 'invisible' }
                )
        ),

    async execute(client, interaction) {
        const ownerRoleId = process.env.OWNER;
        const logThreadId = process.env.LOG_STATUS;

        if (!interaction.member.roles.cache.has(ownerRoleId)) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحية للاستعمال هذا الامر',
                ephemeral: true,
            });
        }

        const newStatus = interaction.options.getString('state');

        try {
            client.user.setPresence({ status: newStatus });

            const logEmbed = new EmbedBuilder()
                .setTitle('🔄 Bot Status Changed')
                .setColor(Colors.Blue)
                .addFields(
                    { name: '👤 تم التغيير بواسطة', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '📊 الحالة الجديدة', value: `\`${newStatus}\``, inline: true },
                    { name: '📅 التاريخ', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setTimestamp();

            const logThread = client.channels.cache.get(logThreadId);
            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            } else {
                console.warn('[Warning] Log thread not found or not a thread!');
            }

            await interaction.reply({ content: `✅ تم تغيير حالة البوت إلى **${newStatus}**`, ephemeral: false });

        } catch (error) {
            console.error(`[Error] Failed to change bot status:`, error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء تغيير حالة البوت',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj