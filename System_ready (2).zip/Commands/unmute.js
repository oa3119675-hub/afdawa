// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('الغاء كتب المستخدم')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('الشخص المراد الغاء كتمه')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الغاء كتمه')
                .setRequired(false)
        ),

    async execute(client, interaction) {
        const adminRoleId = process.env.ADMIN;
        const logThreadId = process.env.LOG_THREAD_MUTE;

        if (!interaction.member.roles.cache.has(adminRoleId)) {
            return interaction.reply({
                content: 'ليس لديك صلاحية للالغاء كتم المستخدم',
                ephemeral: true,
            });
        }

        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided.';
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({
                content: '❌ الشخص غير موجود في السرفر',
                ephemeral: true,
            });
        }

        if (!member.manageable) {
            return interaction.reply({
                content: '❌ لا يمكنني إلغاء كتم صوت هذا المستخدم. قد يكون له دور أعلى مني',
                ephemeral: true,
            });
        }

        if (!member.communicationDisabledUntilTimestamp) {
            return interaction.reply({
                content: '❌ هذا المستخدم ليس مكتوما',
                ephemeral: true,
            });
        }

        try {
            await member.timeout(null);

            // تسجيل في اللوغ
            const logEmbed = new EmbedBuilder()
                .setTitle('🔊 User Unmuted')
                .setColor(Colors.Green)
                .addFields(
                    { name: '👤 Unmuted By', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '👥 User', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '📄 Reason', value: `\`${reason}\``, inline: false },
                    { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setTimestamp();

            const logThread = client.channels.cache.get(logThreadId);
            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            } else {
                console.warn('[Warning] Log thread not found or not a thread!');
            }

            await interaction.reply({ content: `✅ تم إلغاء كتم **${targetUser}**`, ephemeral: false });

        } catch (error) {
            console.error(`[Error] Failed to unmute user:`, error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء إلغاء كتم صوت المستخدم',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj