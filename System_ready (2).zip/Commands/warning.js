// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warning')
        .setDescription('عرض جميع التحذيرات لشخص معين.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('الشخص الذي تريد عرض تحذيراته')
                .setRequired(true)),

    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user');
        const logThreadId = process.env.WARN_LOG;
        const logThread = client.channels.cache.get(logThreadId);
        const allowedRoleIds = process.env.STAFF.split(',');
        const memberRoles = interaction.member.roles.cache;

        if (!allowedRoleIds.some(roleId => memberRoles.has(roleId))) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
                ephemeral: true,
            });
        }

        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            const fileData = fs.readFileSync(warningsFilePath, 'utf8');
            try {
                warningsData = JSON.parse(fileData);
            } catch (error) {
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id] || warningsData[targetUser.id].length === 0) {
            return interaction.reply({
                content: `✅ المستخدم <@${targetUser.id}> لا يملك أي تحذيرات.`,
                ephemeral: true,
            });
        }

        const warningsList = warningsData[targetUser.id]
            .map((warn, index) => `🔹 **تحذير #${index + 1}:**\n**المسؤول:** <@${warn.issuedBy}>\n**السبب:** ${warn.reason}\n**التاريخ:** <t:${Math.floor(new Date(warn.timestamp).getTime() / 1000)}:F>`)
            .join('\n\n');

        const warningsEmbed = new EmbedBuilder()
            .setTitle(`⚠️ سجل تحذيرات ${targetUser.tag}`)
            .setColor('Orange')
            .setDescription(warningsList)
            .setTimestamp()
            .setFooter({ text: `إجمالي التحذيرات: ${warningsData[targetUser.id].length}` });

        if (logThread) {
            logThread.send({
                content: `📜 تم عرض تحذيرات <@${targetUser.id}> بواسطة <@${interaction.user.id}>`,
                embeds: [warningsEmbed]
            });
        }

        interaction.reply({ embeds: [warningsEmbed], ephemeral: true });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj
