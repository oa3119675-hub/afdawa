// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear_msg')
        .setDescription('مسح الرسائل في الغرفة.')
        .addIntegerOption(option =>
            option.setName('number_msg')
                .setDescription('عدد الرسائل التي سيتم مسحها.')
                .setRequired(false)
        ),

    async execute(client, interaction) {
        const allowedRoles = process.env.STAFF ? process.env.STAFF.split(',') : [];
        const logThreadId = process.env.LOG_THREAD_CLEAR_MSG;

        const memberRoles = interaction.member.roles.cache;
        const hasAllowedRole = allowedRoles.some(roleId => memberRoles.has(roleId));

        if (!hasAllowedRole) {
            return interaction.reply({
                content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.',
                ephemeral: false,
            });
        }

        const numberOfMessages = interaction.options.getInteger('number_msg') || 100; 
        const channel = interaction.channel;

        try {
            await interaction.deferReply({ ephemeral: true });

            const deletedMessages = await channel.bulkDelete(numberOfMessages, false);
            await interaction.editReply({
                content: `✅ تم مسح ${deletedMessages.size} رسالة من الغرفة.`,
            });

            const logChannel = await client.channels.fetch(logThreadId);
            if (logChannel && logChannel.isThread()) {
                const logEmbed = {
                    color: 0x0099ff,
                    title: '📌 تقرير مسح الرسائل',
                    fields: [
                        { name: '👮‍♂️ الفاعل', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '📢 الغرفة', value: `${interaction.channel.name}`, inline: true },
                        { name: '📑 عدد الرسائل', value: `${deletedMessages.size}`, inline: true },
                        { name: '📅 التاريخ', value: new Date().toLocaleString('en-US', { timeZone: 'UTC' }) },
                    ],
                    footer: { text: 'تم تسجيل العملية بنجاح' },
                    timestamp: new Date(),
                };
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error('❌ Error while deleting messages:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء محاولة مسح الرسائل.',
                ephemeral: false,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj