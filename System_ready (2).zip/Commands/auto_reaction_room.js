// Code Nexus => https://discord.gg/Tpwgkj9gzj

const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('discord.js');
require('dotenv').config(); // تحميل متغيرات البيئة

const dataPath = path.join(__dirname, 'data', 'auto_reaction.json');
const ADMIN = process.env.ADMIN; // تحميل أيدي الرتب المسموح لها من .env

module.exports = {
    data: new SlashCommandBuilder()
        .setName('auto_reaction_room')
        .setDescription('أضف قناة إلى قائمة التفاعل التلقائي')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('القناة المراد إضافتها')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        // التحقق من الصلاحيات
        if (!interaction.member.roles.cache.has(ADMIN)) {
            return interaction.reply({ content: '❌ ليس لديك الصلاحيات لاستخدام هذا الأمر', ephemeral: true });
        }

        const channel = interaction.options.getChannel('channel');

        try {
            let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
            if (data.channels.includes(channel.id)) {
                return interaction.reply({ content: '⚠️ هذه القناة موجودة بالفعل في قائمة التفاعل التلقائي', ephemeral: false });
            }

            data.channels.push(channel.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));

            interaction.reply({ content: `✅ تمت إضافة ${channel} إلى قائمة التفاعل التلقائي`, ephemeral: false });
        } catch (error) {
            console.error('Error updating auto_reaction.json:', error);
            interaction.reply({ content: '❌ فشل تحديث قائمة التفاعل التلقائي', ephemeral: false });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj