// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nick')
        .setDescription('تغيير لقب المستخدم في السيرفر.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد تغيير لقبه')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('nickname')
                .setDescription('اللقب الجديد للمستخدم')
                .setRequired(true)
        ),
    async execute(client, interaction) {
        const allowedRoleId = process.env.STAFF;
        const logThreadId = process.env.LOG_THREAD_NICK;

        if (!interaction.member.roles.cache.has(allowedRoleId)) {
            return interaction.reply({
                content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.',
                ephemeral: true,
            });
        }

        const targetUser = interaction.options.getUser('user');
        const newNickname = interaction.options.getString('nickname');
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({
                content: '❌ لم يتم العثور على المستخدم في السيرفر.',
                ephemeral: true,
            });
        }
        
        if (!member.manageable) {
            return interaction.reply({
                content: '❌ لا يمكنني تغيير لقب هذا المستخدم. ربما لديه رتبة أعلى مني.',
                ephemeral: true,
            });
        }

        const oldNickname = member.nickname || targetUser.username;

        try {
            await member.setNickname(newNickname);

            const logEmbed = new EmbedBuilder()
                .setTitle('🔄 سجل تغيير الألقاب')
                .setColor(Colors.Green)
                .addFields(
                    { name: '👤 تم التغيير بواسطة', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '👥 المستخدم', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '📝 اللقب السابق', value: `\`${oldNickname}\``, inline: false },
                    { name: '🆕 اللقب الجديد', value: `\`${newNickname}\``, inline: false },
                    { name: '📅 التاريخ', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setTimestamp();

            const logThread = client.channels.cache.get(logThreadId);
            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            } else {
                console.warn('[Warning] Log thread not found or not a thread!');
            }

            await interaction.reply({ content: `✅ تم تغيير لقب ${targetUser} من **${oldNickname}** إلى **${newNickname}** بنجاح!`, ephemeral: true });
        } catch (error) {
            console.error(`[Error] Failed to change nickname:`, error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء محاولة تغيير اللقب. يرجى التأكد من صلاحياتي!',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj