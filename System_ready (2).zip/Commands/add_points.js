// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const POINTS_FILE = path.join(__dirname, '..', 'System', 'data', 'points.json');

const modifyUserPoints = (userId, pointsToAdd) => {
    let pointsData = {};

    const dir = path.dirname(POINTS_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    if (!fs.existsSync(POINTS_FILE)) {
        fs.writeFileSync(POINTS_FILE, JSON.stringify({})); 
    }

    try {
        pointsData = JSON.parse(fs.readFileSync(POINTS_FILE, 'utf8'));
    } catch (err) {
        console.error('❌ خطأ في قراءة ملف النقاط', err);
    }

    if (!pointsData[userId]) {
        pointsData[userId] = 0;
    }

    pointsData[userId] += pointsToAdd;

    try {
        fs.writeFileSync(POINTS_FILE, JSON.stringify(pointsData, null, 2));
        console.log(`تم تعديل النقاط للمستخدم ${userId}: ${pointsData[userId]} نقطة`);
    } catch (err) {
        console.error('❌ خطأ في حفظ ملف النقاط', err);
    }
};




module.exports = {
    data: new SlashCommandBuilder()
        .setName('add_points')
        .setDescription('إضافة أو خصم نقاط من المستخدم.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم المطلوب إضافة/خصم النقاط له.')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('number')
                .setDescription('عدد النقاط المطلوب إضافتها أو خصمها.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('choose')
                .setDescription('اختيار إضافة أو خصم النقاط.')
                .setRequired(true)
                .addChoices(
                    { name: 'إضافة (+)', value: '+' },
                    { name: 'خصم (-)', value: '-' }
                )
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الإضافة/الخصم.')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        const user = interaction.options.getUser('user');
        const number = interaction.options.getInteger('number');
        const choose = interaction.options.getString('choose');
        const reason = interaction.options.getString('reason');

        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
            return interaction.reply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.', ephemeral: true });
        }

        let pointsToAdd = choose === '+' ? number : -number;

        modifyUserPoints(user.id, pointsToAdd);

        return interaction.reply({
            content: `✅ تم ${choose === '+' ? 'إضافة' : 'خصم'} ${number} نقطة(s) من المستخدم ${user.tag}. سبب: ${reason}`,
            ephemeral: true,
        });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj