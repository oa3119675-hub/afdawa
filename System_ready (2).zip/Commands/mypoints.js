// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('@discordjs/builders');

const POINTS_FILE = path.join(__dirname, '..', 'System', 'data', 'points.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mypoints')
    .setDescription('عرض عدد النقاط الخاصة بك.'),

  async execute(client, interaction) {
    const userId = interaction.user.id;
    
    let pointsData = {};
    try {
      pointsData = JSON.parse(fs.readFileSync(POINTS_FILE, 'utf8'));
    } catch (err) {
      console.error('❌ Error reading points file:', err);
      return interaction.reply({ content: 'حدث خطأ أثناء قراءة النقاط.', ephemeral: true });
    }
    
    const userPoints = pointsData[userId] || 0;
    
    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('نـقـاطـك')
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'المستخدم', value: `<@${userId}>`, inline: true },
        { name: 'نقاطك', value: `${userPoints} نقطة`, inline: true }
      )
      .setFooter({ text: 'Point System', iconURL: interaction.client.user.displayAvatarURL() })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj