// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('عرض صورة البروفايل للمستخدم')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد رؤية صورته الشخصية')
                .setRequired(false)),

    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;

        const avatarEmbed = new EmbedBuilder()
            .setColor('Random')
            .setAuthor({
                name: `${targetUser.username}#${targetUser.discriminator}`,
                iconURL: targetUser.displayAvatarURL({ dynamic: true }),
            })
            .setTitle('🖼️ صورة البروفايل')
            .setDescription(`[رابط الصورة الأصلية](${targetUser.displayAvatarURL({ dynamic: true, size: 1024 })})`)
            .setImage(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setFooter({
                text: `By ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
            })
            .setTimestamp();

        await interaction.reply({ embeds: [avatarEmbed] });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj