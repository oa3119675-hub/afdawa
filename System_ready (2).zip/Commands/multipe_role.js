const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('multipe_role')
        .setDescription('إعطاء دور لجميع الأعضاء في السيرفر دفعة واحدة')
        .addRoleOption(option => 
            option.setName('role')
                .setDescription('الدور الذي سيتم إعطاؤه')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        try {
            await interaction.deferReply({ ephemeral: true });

            // جلب معرف رتبة OWNER من .env
            const ownerRoleId = process.env.OWNER;
            if (!ownerRoleId) {
                return interaction.editReply({ content: '❌ لم يتم تحديد معرف رتبة OWNER في الإعدادات.', ephemeral: true });
            }

            // التحقق مما إذا كان المستخدم يمتلك الرتبة
            if (!interaction.member.roles.cache.has(ownerRoleId)) {
                return interaction.editReply({ content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر. يجب أن تمتلك رتبة OWNER.', ephemeral: true });
            }

            const role = interaction.options.getRole('role');
            const guild = interaction.guild;

            let members = await guild.members.fetch();
            let eligibleMembers = members.filter(member => !member.roles.cache.has(role.id) && !member.user.bot);
            let totalMembers = eligibleMembers.size;
            let addedCount = 0;
            let failedCount = 0;
            const batchSize = 10; // عدد الأعضاء في كل دفعة
            const delay = 2000; // مهلة بين كل دفعة (2 ثانية)

            if (totalMembers === 0) {
                return interaction.editReply({ content: `⚠️ جميع الأعضاء لديهم بالفعل هذا الدور!`, ephemeral: true });
            }

            await interaction.editReply({ content: `⏳ جاري إعطاء دور ${role} لجميع الأعضاء... (0/${totalMembers})`, ephemeral: true });

            let membersArray = Array.from(eligibleMembers.values());

            const processBatch = async (batchIndex) => {
                let start = batchIndex * batchSize;
                let end = start + batchSize;
                let batch = membersArray.slice(start, end);

                for (const member of batch) {
                    try {
                        await member.roles.add(role);
                        addedCount++;
                    } catch (error) {
                        console.error(`❌ فشل إعطاء الدور للعضو ${member.user.tag}:`, error);
                        failedCount++;
                    }
                }

                // تحديث رسالة التقدم
                await interaction.editReply({ content: `⏳ جاري إعطاء دور ${role}... (${addedCount}/${totalMembers})`, ephemeral: true });

                // معالجة الدفعة التالية إذا كانت هناك دفعات متبقية
                if (end < totalMembers) {
                    setTimeout(() => processBatch(batchIndex + 1), delay);
                } else {
                    // الانتهاء من العملية
                    await interaction.editReply({ content: `✅ تم إعطاء دور ${role} إلى **${addedCount}** عضوًا بنجاح! (${failedCount} فشلوا)`, ephemeral: true });

                    // إرسال اللوغ
                    const logChannel = client.channels.cache.get(process.env.LOG_MULTIPE_ROLE);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setColor('Green')
                            .setTitle('📌 تم إعطاء دور جماعي')
                            .setDescription(`تم استخدام الأمر من قبل ${interaction.user} لإعطاء دور ${role} إلى **${addedCount}** عضوًا.\n❌ فشل: ${failedCount} عضوًا.`)
                            .setTimestamp();
                        logChannel.send({ embeds: [logEmbed] });
                    }
                }
            };

            // بدء معالجة أول دفعة
            processBatch(0);

        } catch (error) {
            console.error('❌ خطأ أثناء إعطاء الأدوار:', error);
            interaction.editReply({ content: '❌ حدث خطأ أثناء محاولة إعطاء الأدوار.', ephemeral: true });
        }
    }
};