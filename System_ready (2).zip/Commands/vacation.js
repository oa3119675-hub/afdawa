// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('vacation')
        .setDescription('طلب اجازة')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم المطلوب')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('مدة الاجازة (1 to 30 days)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(30)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الاجازة')
                .setRequired(true)
        )
        .addRoleOption(option =>
            option.setName('current_role')
                .setDescription('رتبتك الحالية')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        const { options, member } = interaction;

        if (!member.roles.cache.has(process.env.STAFF)) {
            return interaction.reply({ content: 'ليس لديك صلاحية للاستعمال هذا الامر', ephemeral: false });
        }

        const user = options.getUser('user');
        const duration = options.getInteger('duration');
        const reason = options.getString('reason');
        const currentRole = options.getRole('current_role');

        if (user.bot) {
            return interaction.reply({ content: 'لا يمكن طلب إجازة للروبوتات', ephemeral: false });
        }

        const vacationEmbed = new EmbedBuilder()
            .setTitle('طلب اجازة جديدة')
            .setColor('#00FF00')
            .addFields(
                { name: 'الشخص:', value: `${user}`, inline: true },
                { name: 'المدة:', value: `${duration} أيام`, inline: true },
                { name: 'السبب:', value: reason, inline: false },
                { name: 'الرتبة الحالية:', value: `${currentRole}`, inline: true },
                { name: 'قوانين الاجازات:', value: `
                    1. يجب أن تكون مدة الإجازة ما بين 1 إلى 30 يومًا.
                    2. يجب أن يكون سبب الإجازة واضحًا وصالحًا.
                    3. سيتم مراجعة الطلب من قبل فريق الإدارة.
                    4. قد يؤدي إساءة استخدام نظام الإجازة إلى فرض عقوبات.
                `, inline: false }
            )
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('accept_vacation')
                    .setLabel('قبول')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('reject_vacation')
                    .setLabel('رفض')
                    .setStyle(ButtonStyle.Danger)
            );

        const vacationChannel = client.channels.cache.get(process.env.VACATION_CHANNEL_ID);
        if (vacationChannel) {
            const message = await vacationChannel.send({
                content: `${user}, <@&${process.env.ADMIN}>`,
                embeds: [vacationEmbed],
                components: [buttons]
            });

            await interaction.reply({ content: 'تم إرسال طلب الإجازة بنجاح.', ephemeral: false });

            const filter = (i) => i.customId === 'accept_vacation' || i.customId === 'reject_vacation';
            const collector = message.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async (i) => {
                if (i.customId === 'accept_vacation') {
                    const member = await interaction.guild.members.fetch(user.id);
                    await member.roles.add(process.env.VACATION_ROLE);
                    await user.send(`تم قبول طلب إجازتك. مدة الإجازة: ${duration} أيام.`);
                    await i.reply({ content: `تم قبول طلب إجازة ${user}.`, ephemeral: false });
                } else if (i.customId === 'reject_vacation') {
                    await user.send(`تم رفض طلب إجازتك. الرجاء التواصل مع الإدارة لمزيد من التفاصيل.`);
                    await i.reply({ content: `تم رفض طلب إجازة ${user}.`, ephemeral: false });
                }

                await message.edit({ components: [] });
                collector.stop();
            });
        } else {
            await interaction.reply({ content: 'حدث خطأ أثناء إرسال طلب الإجازة.', ephemeral: true });
        }
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj