// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list_banned')
        .setDescription('عرض قائمة المستخدمين المحظورين'),

    async execute(client, interaction) {
        const bannedUsers = await interaction.guild.bans.fetch();

        if (bannedUsers.size === 0) {
            return interaction.reply({
                content: '❌ لا يوجد أي مستخدمين محظورين.',
                ephemeral: true,
            });
        }

        const sortedBannedUsers = Array.from(bannedUsers.values()).sort((a, b) => b.createdTimestamp - a.createdTimestamp);

        const PAGE_SIZE = 5;
        const totalPages = Math.ceil(sortedBannedUsers.length / PAGE_SIZE);

        let currentPage = 0;

        const allowedRoleIds = process.env.STAFF ? process.env.STAFF.split(',') : [];
        const hasPermission = interaction.member.roles.cache.some(role => allowedRoleIds.includes(role.id));

        if (!hasPermission) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
                ephemeral: false,
            });
        }

        const generateBannedEmbed = (page) => {
            const start = page * PAGE_SIZE;
            const end = start + PAGE_SIZE;
            const pageBannedUsers = sortedBannedUsers.slice(start, end);

            const bannedEmbed = new EmbedBuilder()
                .setTitle('قائمة المستخدمين المحظورين')
                .setColor('Red')
                .setDescription('قائمة المستخدمين المحظورين مرتبة حسب التاريخ:')
                .setTimestamp();

            pageBannedUsers.forEach((ban, index) => {
                const banDate = ban.createdAt ? ban.createdAt.toDateString() : 'غير معروف';
                bannedEmbed.addFields({
                    name: `#${start + index + 1} - ${ban.user.tag}`,
                    value: `**التاريخ:** ${banDate}\n**السبب:** ${ban.reason || 'لا يوجد سبب'}`,
                });
            });

            bannedEmbed.setFooter({ text: `الصفحة ${page + 1} من ${totalPages}` });

            return bannedEmbed;
        };

        const createPaginationButtons = () => {
            return new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('previous')
                    .setLabel('⬅️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === 0),
                
                new ButtonBuilder()
                    .setCustomId('next')
                    .setLabel('➡️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(currentPage === totalPages - 1)
            );
        };

        const message = await interaction.reply({
            embeds: [generateBannedEmbed(currentPage)],
            components: [createPaginationButtons()],
            ephemeral: false,
        });

        const collector = message.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async (buttonInteraction) => {
            if (!buttonInteraction.member.roles.cache.some(role => allowedRoleIds.includes(role.id))) {
                return buttonInteraction.reply({
                    content: '❌ ليس لديك صلاحية للتفاعل مع الأزرار.',
                    ephemeral: false,
                });
            }

            if (buttonInteraction.customId === 'previous' && currentPage > 0) {
                currentPage--;
            } else if (buttonInteraction.customId === 'next' && currentPage < totalPages - 1) {
                currentPage++;
            } else {
                return;
            }

            await buttonInteraction.update({
                embeds: [generateBannedEmbed(currentPage)],
                components: [createPaginationButtons()],
            });
        });

        collector.on('end', () => {
            message.edit({ components: [] });
        });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj