// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const dotenv = require('dotenv');
dotenv.config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unlock')
        .setDescription('الغاء قفل القناة')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('اختر القناة للالغاء القفل عنها')
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels), 

    async execute(client, interaction) {
        const channel = interaction.options.getChannel('channel');
        const adminRole = process.env.ADMIN;
        const logChannel = client.channels.cache.get(process.env.LOG_THREAD_LOCK);

        if (!interaction.member.roles.cache.has(adminRole)) {
            return interaction.reply({ content: '❌ ليس لديك الإذن لاستخدام هذا الأمر', ephemeral: true });
        }

        await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SendMessages: true });

        const embed = new EmbedBuilder()
            .setTitle('🔓 تم الغاء قفل القناة')
            .setDescription(`**القناة:** تم فتح ${channel} بواسطة ${interaction.user}`)
            .setColor(0x00FF00)
            .setTimestamp();

        if (logChannel) logChannel.send({ embeds: [embed] });

        interaction.reply({ content: `✅ Unlocked ${channel}.`, ephemeral: true });
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj