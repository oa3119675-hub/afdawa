// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const dataPath = path.join(__dirname, 'data/auto_reaction.json');
const ADMIN = process.env.ADMIN;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('auto_reaction_remove')
        .setDescription('إزالة قناة من قائمة التفاعل التلقائي')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('القناة المراد إزالتها من قائمة التفاعل التلقائي')
                .setRequired(true)
        ),

    async execute(client, interaction) {
        const channel = interaction.options.getChannel('channel');

        // التحقق من الصلاحيات
        if (!interaction.member.roles.cache.has(ADMIN)) {
            return interaction.reply({ content: '❌ ليس لديك الصلاحيات لاستخدام هذا الأمر', ephemeral: true });
        }

        try {
            let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));

            if (!data.channels.includes(channel.id)) {
                return interaction.reply({ content: `❌ هذه القناة ليست ضمن قائمة التفاعل التلقائي`, ephemeral: false });
            }

            data.channels = data.channels.filter(id => id !== channel.id);
            fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));

            interaction.reply({ content: `✅ تمت إزالة <#${channel.id}> من قائمة التفاعل التلقائي`, ephemeral: false });
        } catch (error) {
            console.error('Error updating auto_reaction.json:', error);
            interaction.reply({ content: '❌ فشل في تحديث القائمة', ephemeral: false });
        }
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj