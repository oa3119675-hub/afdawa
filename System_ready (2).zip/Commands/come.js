// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('come')
        .setDescription('إرسال رسالة استدعاء إلى مستخدم معين.')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('المستخدم المستهدف')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('message')
                .setDescription('الرسالة المراد إرسالها')
                .setRequired(true)),
    
    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user');
        const message = interaction.options.getString('message');
        const channelId = interaction.channel.id;
        const guildId = interaction.guildId;
        const messageId = interaction.id;
        
        try {
            const messageLink = `https://discord.com/channels/${guildId}/${channelId}/${messageId}`;
            
            const embed = new EmbedBuilder()
                .setColor('#3498db')
                .setTitle('📩 استدعاء جديد')
                .setDescription(`\`\`\`${message}\`\`\``)
                .setFooter({ text: 'اضغط على الزر أدناه للانتقال إلى الرسالة الأصلية.' });
            
            const button = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('🔗 الانتقال إلى الطلب')
                    .setStyle(ButtonStyle.Link)
                    .setURL(messageLink)
            );
            
            await targetUser.send({ 
                embeds: [embed],
                components: [button] 
            });
            
            await interaction.reply({ 
                content: `✅ تم إرسال استدعاء إلى ${targetUser.tag}.`, 
                ephemeral: false 
            });
        } catch (error) {
            console.error('❌ Failed to send come:', error);
            await interaction.reply({ content: '❌ حدث خطأ أثناء إرسال الاستدعاء.', ephemeral: false });
        }
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj
