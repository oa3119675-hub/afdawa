// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('إعطاء تحذير لشخص معين.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('الشخص المراد تحذيره')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب التحذير')
                .setRequired(true)),

    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason');
        const logThreadId = process.env.WARN_LOG;
        const logThread = client.channels.cache.get(logThreadId);
        const allowedRoleIds = process.env.STAFF.split(',');
        const memberRoles = interaction.member.roles.cache;

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator) &&
            !allowedRoleIds.some(roleId => memberRoles.has(roleId))) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
                ephemeral: true,
            });
        }

        if (!logThread) {
            return interaction.reply({
                content: '❌ لم يتم العثور على الثريد المخصص لتسجيل التحذيرات.',
                ephemeral: true,
            });
        }

        try {
            await targetUser.send(`🚨 **تحذير من ادارتنا:**\n**السبب:** ${reason}`);
        } catch (error) {
            return interaction.reply({
                content: `❌ لا يمكن إرسال رسالة DM إلى ${targetUser.tag}.`,
                ephemeral: true,
            });
        }

        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            const fileData = fs.readFileSync(warningsFilePath, 'utf8');
            try {
                warningsData = JSON.parse(fileData);
            } catch (error) {
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id]) {
            warningsData[targetUser.id] = [];
        }

        warningsData[targetUser.id].push({
            issuedBy: interaction.user.id,
            reason: reason,
            timestamp: new Date().toISOString(),
        });

        fs.writeFileSync(warningsFilePath, JSON.stringify(warningsData, null, 4));

        const logEmbed = new EmbedBuilder()
            .setTitle('📋 تحذير جديد')
            .setColor('Red')
            .setDescription(`
                **المسؤول:** <@${interaction.user.id}>
                **الشخص المحذر:** <@${targetUser.id}>
                **السبب:** ${reason}
                **التاريخ:** <t:${Math.floor(Date.now() / 1000)}:F>
            `)
            .setTimestamp();

        logThread.send({ embeds: [logEmbed] });

        interaction.reply({
            content: `✅ تم تحذير <@${targetUser.id}> بنجاح.`,
            ephemeral: false,
        });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj