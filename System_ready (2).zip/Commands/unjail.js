// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { jailedMembers } = require('./jail');
require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unjail')
        .setDescription('فك سجن عضو أو إداري في السيرفر')
        .addUserOption(option =>
            option.setName('member')
                .setDescription('الشخص المراد فك سجنه')
                .setRequired(true)
        ),
    async execute(client, interaction) {
        const allowedRoleIds = process.env.OWNER ? process.env.OWNER.split(',') : [];
        const jailRoleId = process.env.JAIL_ROLE;
        const logThreadId = process.env.LOG_THREAD_JAIL;

        const hasPermission = allowedRoleIds.some(roleId =>
            interaction.member.roles.cache.has(roleId)
        );

        if (!hasPermission) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحيات لتنفيذ هذا الأمر.',
                ephemeral: true,
            });
        }

        const member = interaction.options.getMember('member');
        if (!member) {
            return interaction.reply({
                content: '❌ لم أستطع العثور على هذا العضو.',
                ephemeral: true,
            });
        }

        if (!jailedMembers.has(member.id)) {
            return interaction.reply({
                content: '❌ العضو غير مسجون.',
                ephemeral: true,
            });
        }

        const originalRoles = jailedMembers.get(member.id);
        if (!originalRoles) {
            return interaction.reply({
                content: '❌ لم أتمكن من استرجاع الأدوار الأصلية لهذا العضو.',
                ephemeral: true,
            });
        }

        try {
            await interaction.deferReply();

            const jailRole = interaction.guild.roles.cache.get(jailRoleId);
            if (jailRole) {
                await member.roles.remove(jailRole);
            }

            for (const roleId of originalRoles) {
                const role = interaction.guild.roles.cache.get(roleId);
                if (role) {
                    await member.roles.add(role);
                }
            }

            const guild = interaction.guild;
            const allChannels = guild.channels.cache.filter(channel => channel.isTextBased());

            for (const channel of allChannels.values()) {
                if (channel.permissionOverwrites) {
                    await channel.permissionOverwrites.edit(member, {
                        [PermissionsBitField.Flags.ViewChannel]: null 
                    });
                }
            }

            const logThread = guild.channels.cache.get(logThreadId);

            if (logThread && logThread.isThread()) {
                const logDate = new Date().toLocaleString('en-US', { timeZone: 'UTC', hour12: false });
                const logEmbed = new EmbedBuilder()
                    .setColor('#00FF00')
                    .setTitle('🚨 Unjail Log')
                    .setDescription('تفاصيل عملية فك السجن')
                    .addFields(
                        { name: '👮‍♂️ الفاعل', value: `<@${interaction.member.id}>`, inline: true },
                        { name: '👤 المتهم', value: `<@${member.id}>`, inline: true },
                        { name: '📅 التاريخ', value: logDate, inline: false }
                    )
                    .setFooter({ text: 'تم تسجيل العملية بنجاح', iconURL: interaction.guild.iconURL() })
                    .setTimestamp();

                await logThread.send({ embeds: [logEmbed] });
            }

            await interaction.editReply({
                content: `✅ تم فك سجن <@${member.id}> بنجاح!`,
                ephemeral: false,
            });

            jailedMembers.delete(member.id);
        } catch (error) {
            console.error('❌ Error while trying to unlock member', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء محاولة فك سجن العضو.',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj