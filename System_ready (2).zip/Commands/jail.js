// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');
require('dotenv').config();

const NO_JAIL = process.env.OWNER.split(',');
const ALLOWED_JAIL = process.env.OWNER.split(',');
const JAIL_ROLE = process.env.JAIL_ROLE;
const SHOW_CHANNEL = process.env.SHOW_CHANNEL.split(',');
const ROLE_SKIP = process.env.ROLE_SKIP.split(',');
const LOG_THREAD_JAIL = process.env.LOG_THREAD_JAIL;

const jailedMembers = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('jail')
        .setDescription('سجن عضو أو إداري في السيرفر')
        .addUserOption(option =>
            option.setName('member')
                .setDescription('الشخص المراد سجنه')
                .setRequired(true)
        ),
    async execute(client, interaction) {
        const hasPermission = ALLOWED_JAIL.some(roleId =>
            interaction.member.roles.cache.has(roleId)
        );

        if (!hasPermission) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحيات لتنفيذ هذا الأمر.',
                ephemeral: false,
            });
        }

        const member = interaction.options.getMember('member');
        if (!member) {
            return interaction.reply({
                content: '❌ لم أستطع العثور على هذا العضو',
                ephemeral: false,
            });
        }

        if (member.id === interaction.member.id) {
            return interaction.reply({
                content: '❌ لا يمكنك سجن نفسك',
                ephemeral: false,
            });
        }
        
        if (NO_JAIL.includes(member.id)) {
            return interaction.reply({
                content: '❌ هذا الأونر محمي من السجن',
                ephemeral: false,
            });
        }

        const jailRole = interaction.guild.roles.cache.get(JAIL_ROLE);
        if (!jailRole) {
            return interaction.reply({
                content: '❌ لم يتم العثور على دور Jail. تأكد من أن الـ ID صحيح وأن الدور موجود',
                ephemeral: true,
            });
        }

        try {
            await interaction.deferReply();

            const originalRoles = member.roles.cache
                .filter(role =>
                    role.id !== interaction.guild.id && 
                    !ROLE_SKIP.includes(role.id)
                )
                .map(role => role.id);

            jailedMembers.set(member.id, originalRoles);

            const rolesToRemove = member.roles.cache.filter(role =>
                role.id !== interaction.guild.id &&
                !ROLE_SKIP.includes(role.id) &&
                !role.permissions.has(PermissionsBitField.Flags.Administrator)
            );

            for (const role of rolesToRemove.values()) {
                await member.roles.remove(role);
            }

            await member.roles.add(jailRole);

            const guild = interaction.guild;
            const allChannels = guild.channels.cache.filter(channel => channel.isTextBased());

            for (const channel of allChannels.values()) {
                if (channel.permissionOverwrites) {
                    if (!SHOW_CHANNEL.includes(channel.id)) {
                        await channel.permissionOverwrites.edit(member, {
                            [PermissionsBitField.Flags.ViewChannel]: false
                        });
                    } else {
                        await channel.permissionOverwrites.edit(member, {
                            [PermissionsBitField.Flags.ViewChannel]: true
                        });
                    }
                }
            }

            const logThread = guild.channels.cache.get(LOG_THREAD_JAIL);

            if (logThread && logThread.isThread()) {
                const logDate = new Date().toLocaleString('en-US', { timeZone: 'UTC', hour12: false });
                const logEmbed = new EmbedBuilder()
                    .setColor('#FF0000')
                    .setTitle('🚨 Jail Log')
                    .setDescription('تفاصيل عملية السجن')
                    .addFields(
                        { name: '👮‍♂️ الفاعل', value: `<@${interaction.member.id}>`, inline: true },
                        { name: '👤 المتهم', value: `<@${member.id}>`, inline: true },
                        { name: '📅 التاريخ', value: logDate, inline: false }
                    )
                    .setFooter({ text: 'تم تسجيل العملية بنجاح', iconURL: interaction.guild.iconURL() })
                    .setTimestamp();

                await logThread.send({ embeds: [logEmbed] });
            }

            await interaction.editReply({
                content: `✅ تم سجن <@${member.id}> بنجاح!`,
                ephemeral: false,
            });
        } catch (error) {
            console.error('❌ Error while trying to jail the member:', error);
            await interaction.editReply({
                content: '❌ حدث خطأ أثناء محاولة سجن العضو.',
                ephemeral: false,
            });
        }
    },
};

module.exports.jailedMembers = jailedMembers;

// Code Nexus => https://discord.gg/Tpwgkj9gzj