// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, Colors } = require('discord.js');
require('dotenv').config();

const ALLOWED_USED_KICK = process.env.OWNER.split(',');
const KICK_LOG = process.env.KICK_LOG;

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('طرد مستخدم معين من الخادم.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد طرده.')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الطرد.')
                .setRequired(false)),

    async execute(client, interaction) {
        await interaction.deferReply({ ephemeral: true });

        const targetUser = interaction.options.getMember('user');
        const reason = interaction.options.getString('reason') || 'لم يتم تحديد السبب.';

        if (!targetUser) {
            return interaction.editReply({ content: '❌ لا يمكن العثور على هذا المستخدم في السيرفر.' });
        }

        const hasAllowedRole = interaction.member.roles.cache.some(role => ALLOWED_USED_KICK.includes(role.id));
        if (!hasAllowedRole) {
            return interaction.editReply({ content: '❌ ليس لديك الصلاحية لاستخدام هذا الأمر.' });
        }

        if (!targetUser.kickable) {
            return interaction.editReply({ content: '❌ لا يمكنني طرد هذا المستخدم. تأكد من أن رتبتي أعلى من رتبته.' });
        }

        try {
            await targetUser.kick(reason);
            await interaction.editReply({ content: `✅ تم طرد ${targetUser} بنجاح.\n**السبب:** ${reason}` });

            const logChannel = client.channels.cache.get(KICK_LOG);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🚨 طرد عضو 🚨')
                    .setColor(Colors.Red)
                    .addFields(
                        { name: '👤 العضو المطرود', value: `${targetUser.user.tag} (${targetUser.id})`, inline: false },
                        { name: '🛠 تم الطرد بواسطة', value: `${interaction.user.tag} (${interaction.user.id})`, inline: false },
                        { name: '📄 السبب', value: reason, inline: false }
                    )
                    .setTimestamp();
                
                await logChannel.send({ embeds: [logEmbed] });
            }
        } catch (error) {
            console.error(error);
            return interaction.editReply({ content: '❌ An error occurred while trying to kick the user' });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj