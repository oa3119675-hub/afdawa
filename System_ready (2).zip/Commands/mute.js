// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { SlashCommandBuilder, EmbedBuilder, Colors, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('كتم صوت المستخدم لمدة محددة مع ذكر السبب')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('الشخص المراد كتمه')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('مدة الكتم (e.g., 10m, 1h, 2d)')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب الكتم')
                .setRequired(false)
        ),
    
    async execute(client, interaction) {
        const adminRoleId = process.env.ADMIN;
        const logThreadId = process.env.LOG_THREAD_MUTE;

        if (!interaction.member.roles.cache.has(adminRoleId)) {
            return interaction.reply({
                content: '❌ ليس لديك الإذن لاستخدام هذا الأمر',
                ephemeral: true,
            });
        }

        const targetUser = interaction.options.getUser('user');
        const duration = interaction.options.getString('duration');
        const reason = interaction.options.getString('reason') || 'No reason provided.';
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({
                content: '❌ لم يتم العثور على المستخدم في الخادم',
                ephemeral: true,
            });
        }

        if (!member.manageable) {
            return interaction.reply({
                content: '❌ لا يمكنني كتم صوت هذا المستخدم. قد يكون له دور أعلى مني او هو اونر',
                ephemeral: true,
            });
        }

        const timeMap = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
        const match = duration.match(/^(\d+)([smhd])$/);

        if (!match) {
            return interaction.reply({
                content: '❌ Invalid duration format. Use **s (seconds), m (minutes), h (hours), d (days)** (e.g., `10m`, `1h`, `2d`).',
                ephemeral: true,
            });
        }

        const timeValue = parseInt(match[1]);
        const timeUnit = match[2];
        const muteDuration = timeValue * timeMap[timeUnit];

        if (isNaN(muteDuration) || muteDuration <= 0) {
            return interaction.reply({
                content: '❌قيمة مدة غير صالحة',
                ephemeral: true,
            });
        }

        try {
            await member.timeout(muteDuration, reason);

            const logEmbed = new EmbedBuilder()
                .setTitle('🔇 User Muted')
                .setColor(Colors.Red)
                .addFields(
                    { name: '👤 Muted By', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                    { name: '👥 User', value: `${targetUser} (${targetUser.tag})`, inline: true },
                    { name: '🕒 Duration', value: `\`${duration}\``, inline: true },
                    { name: '📄 Reason', value: `\`${reason}\``, inline: false },
                    { name: '📅 Date', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                )
                .setTimestamp();

            const logThread = client.channels.cache.get(logThreadId);
            if (logThread && logThread.isThread()) {
                await logThread.send({ embeds: [logEmbed] });
            } else {
                console.warn('[Warning] Log thread not found or not a thread');
            }

            await interaction.reply({ content: `✅ تم كتم صوت **${targetUser}** لمدة **${duration}**`, ephemeral: false });

            setTimeout(async () => {
                if (member.communicationDisabledUntilTimestamp > Date.now()) {
                    try {
                        await member.timeout(null);
                        
                        const unmuteEmbed = new EmbedBuilder()
                            .setTitle('🔊 User Unmuted')
                            .setColor(Colors.Green)
                            .addFields(
                                { name: '👥 User', value: `${targetUser} (${targetUser.tag})`, inline: true },
                                { name: '⏳ Duration', value: `\`${duration}\``, inline: true },
                                { name: '📅 Unmuted At', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
                            )
                            .setTimestamp();
                        
                        if (logThread && logThread.isThread()) {
                            await logThread.send({ embeds: [unmuteEmbed] });
                        }
                    } catch (err) {
                        console.error(`[Error] Failed to unmute user:`, err);
                    }
                }
            }, muteDuration);

        } catch (error) {
            console.error(`[Error] Failed to mute user:`, error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء كتم صوت المستخدم. يرجى التحقق من أذوناتي',
                ephemeral: true,
            });
        }
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj