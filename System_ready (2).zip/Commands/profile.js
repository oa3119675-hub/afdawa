// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('عرض معلومات مفصلة عن ملف تعريف المستخدم')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد عرض ملفه الشخصي')
                .setRequired(false)),

    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = await interaction.guild.members.fetch(targetUser.id);

        const profileEmbed = new EmbedBuilder()
            .setColor('Blue')
            .setAuthor({
                name: targetUser.tag,
                iconURL: targetUser.displayAvatarURL({ dynamic: true }),
            })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setTitle('📄 ملف المستخدم الشخصي')
            .addFields(
                { name: '👤 **اسم المستخدم**', value: targetUser.tag, inline: true },
                { name: '🆔 **معرف المستخدم**', value: targetUser.id, inline: true },
                {
                    name: '📅 **تاريخ إنشاء الحساب**',
                    value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>`,
                    inline: false,
                },
                {
                    name: '📥 **تاريخ الانضمام للسيرفر**',
                    value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`,
                    inline: false,
                },
            )
            .setFooter({
                text: `By ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
            })
            .setTimestamp();

        await interaction.reply({ embeds: [profileEmbed] });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj