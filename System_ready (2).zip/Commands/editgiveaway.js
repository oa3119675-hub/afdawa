// Code Nexus => https://discord.gg/Tpwgkj9gzj

const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('edit_giveaway')
        .setDescription('تعديل الهدية الحالية عن طريق معرف الرسالة')
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('معرف الرسالة الخاصة بالغيفواي المراد تعديلها')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('name')
                .setDescription('العنوان الجديد للمسابقة')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('المدة الجديدة للعرض الترويجي (على سبيل المثال، 6 ساعات، أو يومين، أو 30 دقيقة)')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('العدد الجديد للفائزين')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('الجائزة الجديدة للمسابقة')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('host')
                .setDescription('المضيف الجديد للمسابقة'))
        .addStringOption(option =>
            option.setName('banner')
                .setDescription('عنوان رابط لصورة الشعار الجديد (اختياري)'))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('عنوان رابط للصورة المصغرة الجديدة (اختياري)')),

        async execute(client, interaction) {
            const allowedRoles = [
                process.env.ADMIN
        ];

        const memberRoles = interaction.member.roles.cache.map(role => role.id);
        const hasPermission = allowedRoles.some(role => memberRoles.includes(role));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ ليس لديك الصلاحيات اللازمة لاستخدام هذا الأمر.',
                ephemeral: false
            });
        }

        const messageId = interaction.options.getString('message_id');
        const name = interaction.options.getString('name');
        const duration = interaction.options.getString('duration');
        const winners = interaction.options.getInteger('winners');
        const prize = interaction.options.getString('prize');
        const host = interaction.options.getUser('host');
        const banner = interaction.options.getString('banner');
        const thumbnail = interaction.options.getString('thumbnail');

        const durationMs = parseDuration(duration);

        if (durationMs === null) {
            await interaction.reply({ content: '❌ تنسيق المدة غير صالح. يُرجى استخدام "h" أو "d" أو "m" (على سبيل المثال، 6h، 2d، 30m).', ephemeral: false });
            return;
        }

        const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
        const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

        const giveawayEntry = giveawayData.find(entry => entry.id === messageId);
        if (!giveawayEntry) {
            await interaction.reply({ content: '❌ لم يتم العثور على الغيفواي مع معرف الرسالة المقدم', ephemeral: false });
            return;
        }

        giveawayEntry.name = name;
        giveawayEntry.duration = duration;
        giveawayEntry.winners = winners;
        giveawayEntry.prize = prize;
        giveawayEntry.host = host ? host.username : 'Anonymous';
        giveawayEntry.banner = banner || giveawayEntry.banner;
        giveawayEntry.thumbnail = thumbnail || giveawayEntry.thumbnail;

        const embed = new EmbedBuilder()
            .setTitle(`🎉 Giveaway: ${name}`)
            .setDescription(`**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends In:** <t:${Math.floor((Date.now() + durationMs) / 1000)}:R>\n**Hosted By:** ${host ? host : 'Anonymous'}`)
            .setColor('Blue')
            .setFooter({ text: 'اضغط على زر اسفله للمشاركة' });

        if (banner) embed.setImage(banner);
        if (thumbnail) embed.setThumbnail(thumbnail);

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_enter')
                    .setLabel('🎉 شارك')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('giveaway_participants')
                    .setLabel('📋 المشاركين')
                    .setStyle(ButtonStyle.Secondary)
            );

        try {
            const giveawayChannel = interaction.channel;
            const giveawayMessage = await giveawayChannel.messages.fetch(messageId);
            
            if (!giveawayMessage) {
                throw new Error("Message not found");
            }

            await giveawayMessage.edit({ embeds: [embed], components: [button] });
            
            fs.writeFileSync(giveawayDataPath, JSON.stringify(giveawayData, null, 2));

            await interaction.reply({ content: `✅ غيفواي مع معرف الرسالة ${messageId} تم التحديث بنجاح!`, ephemeral: false });
        } catch (error) {
            console.error('❌ Error editing giveaway message:', error);
            await interaction.reply({
                content: '❌ لم نتمكن من العثور على الرسالة أو تعديلها. يرجى التحقق من المعرف.',
                ephemeral: true
            });
        }
    }
};

function parseDuration(duration) {
    const regex = /^(\d+)(h|d|m)$/;
    const match = duration.match(regex);

    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 'h':
            return value * 60 * 60 * 1000;
        case 'd':
            return value * 24 * 60 * 60 * 1000;
        case 'm':
            return value * 60 * 1000;
        default:
            return null;
    }
}


function parseDuration(duration) {
    const regex = /^(\d+)(h|d|m)$/;
    const match = duration.match(regex);

    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 'h':
            return value * 60 * 60 * 1000;
        case 'd':
            return value * 24 * 60 * 60 * 1000;
        case 'm':
            return value * 60 * 1000;
        default:
            return null;
    }
}

// Code Nexus => https://discord.gg/Tpwgkj9gzj