// Code Nexus => https://discord.gg/Tpwgkj9gzj

const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('discord.js');

require('dotenv').config();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway_delete')
        .setDescription('حذف غيفواي باستخدام معرف الرسالة')
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('معرّف الرسالة للغيفواي الذي تريد حذفه')
                .setRequired(true)),

        async execute(client, interaction) {
            const allowedRoles = [
                process.env.ADMIN
        ];
                

        const memberRoles = interaction.member.roles.cache.map(role => role.id);
        const hasPermission = allowedRoles.some(role => memberRoles.includes(role));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ ليس لديك الصلاحيات اللازمة لاستخدام هذا الأمر.',
                ephemeral: false
            });
        }

        const messageId = interaction.options.getString('message_id');

        const giveawayChannel = interaction.channel;

        const giveawayMessage = await giveawayChannel.messages.fetch(messageId).catch(() => null);
        if (!giveawayMessage) {
            return await interaction.reply({ content: '❌ لم يتم العثور على رسالة الغيفواي بهذا المعرف!', ephemeral: false });
        }

        await giveawayMessage.delete().catch(() => null);

        const giveawayDataPath = path.join(__dirname, 'data', 'addgiveaway.json');
        const giveawayData = JSON.parse(fs.readFileSync(giveawayDataPath, 'utf-8') || '[]');

        const updatedData = giveawayData.filter(entry => entry.id !== messageId);

        fs.writeFileSync(giveawayDataPath, JSON.stringify(updatedData, null, 2));

        await interaction.reply({ content: `✅ تم حذف الغيفواي بمعرّف الرسالة ${messageId} بنجاح`, ephemeral: false });
    }
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj