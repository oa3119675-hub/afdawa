// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const warningsFilePath = path.join(__dirname, 'data', 'warning.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unwarn')
        .setDescription('إزالة تحذير عن شخص معين.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('الشخص الذي تريد إزالة التحذير عنه')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب إزالة التحذير')
                .setRequired(true)),

    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason');
        const logThreadId = process.env.WARN_LOG;
        const logThread = client.channels.cache.get(logThreadId);
        const allowedRoleIds = process.env.STAFF.split(',');
        const memberRoles = interaction.member.roles.cache;

        if (!allowedRoleIds.some(roleId => memberRoles.has(roleId))) {
            return interaction.reply({
                content: '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
                ephemeral: true,
            });
        }

        if (!logThread) {
            return interaction.reply({
                content: '❌ لم يتم العثور على الثريد المخصص لتسجيل إزالة التحذيرات.',
                ephemeral: true,
            });
        }

        let warningsData = {};
        if (fs.existsSync(warningsFilePath)) {
            const fileData = fs.readFileSync(warningsFilePath, 'utf8');
            try {
                warningsData = JSON.parse(fileData);
            } catch (error) {
                warningsData = {};
            }
        }

        if (!warningsData[targetUser.id] || warningsData[targetUser.id].length === 0) {
            return interaction.reply({
                content: `❌ المستخدم <@${targetUser.id}> لا يملك أي تحذيرات.`,
                ephemeral: true,
            });
        }

        const removedWarning = warningsData[targetUser.id].pop();

        fs.writeFileSync(warningsFilePath, JSON.stringify(warningsData, null, 4));

        const logEmbed = new EmbedBuilder()
            .setTitle('🛑 إزالة تحذير')
            .setColor('Green')
            .setDescription(`
                **المسؤول:** <@${interaction.user.id}>
                **الشخص المستهدف:** <@${targetUser.id}>
                **السبب الجديد:** ${reason}
                
                **🔻 تفاصيل التحذير المحذوف:**
                **المسؤول الذي أعطى التحذير:** <@${removedWarning.issuedBy}>
                **السبب السابق:** ${removedWarning.reason}
                **التاريخ:** <t:${Math.floor(new Date(removedWarning.timestamp).getTime() / 1000)}:F>
            `)
            .setTimestamp();

        logThread.send({ embeds: [logEmbed] });

        interaction.reply({
            content: `✅ تم إزالة تحذير عن <@${targetUser.id}> بنجاح.`,
            ephemeral: false,
        });
    },
};

// Code Nexus => https://discord.gg/Tpwgkj9gzj