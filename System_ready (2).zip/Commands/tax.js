// Code Nexus => https://discord.gg/Tpwgkj9gzj

const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tax')
        .setDescription('قم بحساب ضريبة بروبوت')
        .addStringOption(option =>
            option.setName('amount')
                .setDescription('قم بادخال الرقم  (e.g., 600k, 2m, 5b, or 10000)')
                .setRequired(true)
        ),
    async execute(client, interaction) {
        try {
            await interaction.deferReply();

            const amountInput = interaction.options.getString('amount');
            const amount = parseAmount(amountInput);

            if (amount === null) {
                return interaction.editReply({ content: '❌ يرجى إدخال مبلغ صالح (مثل 600k أو 2m أو 5b أو 10000).', ephemeral: true });
            }

            if (amount <= 0) {
                return interaction.editReply({ content: '❌ يرجى إدخال مبلغ صالح أكبر من الصفر.', ephemeral: true });
            }

            const tax2 = Math.floor(amount * (20) / (19) + (1) - amount);
            const finalAmount = amount + tax2;

            const color = determineColor(finalAmount);

            const embed = new EmbedBuilder()
                .setTitle('نتائج حساب ضريبة بروبوت')
                .setColor(color)
                .setThumbnail('https://cdn.discordapp.com/attachments/1308882544770420766/1310001716141232128/Default_The_image_shows_a_3D_icon_representing_Tax_It_consists_1_bb7b5b3a-8b79-4b1a-a25b-f2571067dbe4_0.png')
                .addFields(
                    { name: 'المبلغ الأصلي', value: `${amount}`, inline: true },
                    { name: 'المبلغ المخصم', value: `${tax2}`, inline: true },
                    { name: 'المبلغ النهائي', value: `\`\`\`${finalAmount}\`\`\``, inline: false }
                )
                .setFooter({ text: `${client.user.username} - ${new Date().toLocaleString()}` })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('aboutus')
                        .setLabel('About us')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('changeLanguage')
                        .setLabel('Change Language')
                        .setStyle(ButtonStyle.Success)
                );

            await interaction.editReply({ embeds: [embed], components: [row] });

            const filter = (btnInteraction) => btnInteraction.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

            let isArabic = false;

            collector.on('collect', async (btnInteraction) => {
                if (btnInteraction.customId === 'changeLanguage') {
                    isArabic = !isArabic;

                    embed.setTitle(isArabic ? 'Probot Tax Calculation Results' : 'نتائج حساب ضريبة بروبوت')
                        .setFields([
                            { name: isArabic ? 'Original Amount' : 'المبلغ الأصلي', value: `${amount}`, inline: true },
                            { name: isArabic ? 'Broker Tax' : 'المبلغ المخصم', value: `${tax2}`, inline: true },
                            { name: isArabic ? 'Final Amount' : 'المبلغ النهائي', value: `\`\`\`${finalAmount}\`\`\``, inline: false }
                        ]);

                    row.components[0].setLabel(isArabic ? 'تعرف علينا' : 'About us');
                    row.components[1].setLabel(isArabic ? 'تغيير اللغة' : 'Change Language');

                    await btnInteraction.update({ embeds: [embed], components: [row] });
                } else if (btnInteraction.customId === 'aboutus') {
                    const aboutEmbed = new EmbedBuilder()
                        .setTitle(isArabic ? 'تعرف على ProTax' : 'About ProTax')
                        .setColor('#f5b7b1')
                        .setThumbnail('https://cdn.discordapp.com/attachments/1308882544770420766/1310009970762321920/cropped-PB.png')
                        .addFields(
                            { name: isArabic ? 'الوصف' : 'Description', value: isArabic ? 'يعتبر دور البوت هو يقوم بحساب ضريبة بروبوت بشكل سهل و معرفة كم المبلغ التي سوف يصل للمستخدم حسب تحديدك للمبلغ المعين' : 'The role of the ProTax Bot is to calculate the probot tax easily and know the amount that will reach the user according to your specification of the specified amount' },
                            { name: isArabic ? 'تم التطوير بواسطة' : 'Developed By', value: 'rewebby | 756947441592303707' },
                            { name: isArabic ? 'السرفر للدعم وشراء البوت' : 'Server for Support & Purchasing', value: '[Support Server](https://discord.gg/YkEy6d7TzQ)', inline: false },
                            { name: isArabic ? 'التكنولوجيا المستخدمة' : 'Technologies Used', value: 'Node.js, Discord.js, JavaScript', inline: false },
                        )
                        .setImage('https://cdn.discordapp.com/attachments/1308882544770420766/1310009970372382833/17f22523900c3a49d6e21e9d72fac5da.jpg')
                        .setFooter({ text: 'ProTax Bot' })
                        .setTimestamp();

                    await btnInteraction.reply({ embeds: [aboutEmbed], ephemeral: true });
                }
            });

            collector.on('end', async () => {
                await interaction.editReply({ content: '⏳ انتهت مدة التفاعل. الرجاء إعادة المحاولة.', components: [] });
            });
        } catch (error) {
            console.error('An error occurred:', error);
            await interaction.editReply({ content: '❌ حدث خطأ أثناء معالجة طلبك.', ephemeral: true });
        }
    },
};

function parseAmount(input) {
    const regex = /^(\d+(\.\d+)?)(k|m|b)$/i;
    const match = input.match(regex);

    if (match) {
        let amount = parseFloat(match[1]);
        const unit = match[3].toLowerCase();

        if (unit === 'k') {
            return amount * 1000;
        } else if (unit === 'm') {
            return amount * 1000000;
        } else if (unit === 'b') {
            return amount * 1000000000;
        }
    }

    const realAmount = parseFloat(input);
    return isNaN(realAmount) ? null : realAmount;
}

function determineColor(finalAmount) {
    if (finalAmount <= 1) return '#8e44ad';
    else if (finalAmount <= 10) return '#9b59b6';
    else if (finalAmount <= 100) return '#af7ac5';
    else if (finalAmount <= 1000) return '#d2b4de';
    else if (finalAmount <= 10000) return '#e8daef';
    else if (finalAmount <= 100000) return '#f5b7b1';
    else if (finalAmount <= 1000000) return '#f1948a';
    else if (finalAmount <= 10000000) return '#ec7063';
    else if (finalAmount <= 100000000) return '#ff1900';
    else if (finalAmount <= 1000000000) return '#ff005d';
    else if (finalAmount <= 10000000000) return '#ff00ff';
    else if (finalAmount <= 100000000000) return '#fff200';
    else return '#f8c6d8';
}

// Code Nexus => https://discord.gg/Tpwgkj9gzj