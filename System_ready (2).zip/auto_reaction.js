const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, '../Commands/data/auto_reaction.json');

module.exports = {
    name: 'auto_reaction',
    execute(client) {
        client.on('messageCreate', async (message) => {
            if (message.author.bot) return;

            try {
                let data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
                if (data.channels.includes(message.channel.id)) {
                    await message.react('👍🏼');
                    await message.react('👎🏼');
                }
            } catch (error) {
                console.error('Error reading auto_reaction.json:', error);
            }
        });
    }
};
