const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

const afkFilePath = path.join(__dirname, '../Commands/data/afk.json');

const loadAFKData = () => {
    if (!fs.existsSync(afkFilePath)) return {};
    return JSON.parse(fs.readFileSync(afkFilePath, 'utf8'));
};

const saveAFKData = (data) => {
    fs.writeFileSync(afkFilePath, JSON.stringify(data, null, 2));
};

const removeAFKStatus = (message, afkData, client) => {
    if (!afkData[message.author.id]) return;

    const userData = afkData[message.author.id];

    if (userData.mentions.length > 0) {
        const embed = new EmbedBuilder()
            .setColor(0x00ff00)
            .setTitle('Welcome Back!')
            .setDescription('Your AFK status has been removed. Here are your mentions:')
            .setTimestamp()
            .setFooter({ text: 'AFK Bot', iconURL: client.user.displayAvatarURL() });

        userData.mentions.forEach((mention, index) => {
            embed.addFields({
                name: `Message ${index + 1}`,
                value: `**From:** <@${mention.authorId}>\n**Message:** [Click here](${mention.link})\n**Content:** ${mention.content}`,
            });
        });

        message.author.send({ embeds: [embed] }).catch(err => console.error('Failed to send DM:', err));
    }

    delete afkData[message.author.id];
    saveAFKData(afkData);

    message.reply({
        embeds: [new EmbedBuilder().setColor(0x00ff00).setTitle('AFK Status Removed!').setDescription('Welcome back!')],
    });
};

module.exports = {
    name: 'afkHandler',
    execute(client) {
        client.on('messageCreate', async (message) => {
            if (message.author.bot) return;

            const afkData = loadAFKData();

            if (afkData[message.author.id]) {
                removeAFKStatus(message, afkData, client);
            }

            message.mentions.users.forEach(user => {
                if (afkData[user.id]) {
                    const userData = afkData[user.id];

                    const afkEmbed = new EmbedBuilder()
                        .setColor(0xff0000)
                        .setTitle('User is currently AFK')
                        .setDescription(`**User:** <@${user.id}>\n**Reason:** ${userData.reason}`)
                        .setTimestamp()
                        .setFooter({ text: 'AFK Bot', iconURL: client.user.displayAvatarURL() });

                    message.reply({ embeds: [afkEmbed] });

                    if (!userData.mentions) userData.mentions = [];
                    userData.mentions.push({
                        authorId: message.author.id,
                        content: message.content,
                        link: `https://discord.com/channels/${message.guild.id}/${message.channel.id}/${message.id}`,
                    });

                    saveAFKData(afkData);
                }
            });
        });
    }
};
