const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'restartButton',
  execute(client) {
    client.once('ready', async () => {
      const restartChannelId = process.env.RESTART_CHANNEL;
      
      if (!restartChannelId) {
        console.log('⚠️ RESTART_CHANNEL not configured, skipping restart button');
        return;
      }

      try {
        const channel = await client.channels.fetch(restartChannelId);
        
        if (!channel) {
          console.log('❌ لم أتمكن من إيجاد روم إعادة التشغيل');
          return;
        }

        // Embed الرسالة
        const embed = new EmbedBuilder()
          .setTitle('🔄 إعادة تشغيل البوت')
          .setDescription('اضغط على الزر أدناه لإعادة تشغيل البوت (Admins فقط)')
          .setColor('#00bfff');

        // الزر
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('restart_bot')
              .setLabel('🔄 إعادة تشغيل البوت')
              .setStyle(ButtonStyle.Danger)
          );

        // إرسال الرسالة
        await channel.send({ embeds: [embed], components: [row] });
        console.log('✅ زر إعادة تشغيل البوت تم إرساله في الروم المحدد');
      } catch (error) {
        console.error('❌ خطأ في إرسال زر إعادة التشغيل:', error.message);
      }
    });
  }
};
