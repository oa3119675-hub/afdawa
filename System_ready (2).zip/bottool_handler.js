const { EmbedBuilder } = require('discord.js');
const { getAnalytics } = require('./ticket_analytics');

module.exports = {
  name: 'bottoolHandler',
  execute(client) {
    client.on('interactionCreate', async (interaction) => {
      if (!interaction.isButton()) return;

      // Handle bottool buttons
      if (interaction.customId === 'bottool_tickets') {
        const analytics = getAnalytics();
        const pending = analytics.totalTickets - analytics.closedTickets;
        
        const ticketsEmbed = new EmbedBuilder()
          .setTitle('🎫 إدارة التذاكر')
          .setDescription('إحصائيات التذاكر الشاملة')
          .setColor(0x00AE86)
          .addFields([
            { name: '📊 إجمالي التذاكر', value: `${analytics.totalTickets}`, inline: true },
            { name: '✅ التذاكر المغلقة', value: `${analytics.closedTickets}`, inline: true },
            { name: '⏳ التذاكر المعلقة', value: `${pending}`, inline: true },
            { name: '🔴 أولوية عالية', value: `${analytics.byPriority.high}`, inline: true },
            { name: '🟠 أولوية متوسطة', value: `${analytics.byPriority.medium}`, inline: true },
            { name: '🟢 أولوية منخفضة', value: `${analytics.byPriority.low}`, inline: true }
          ])
          .setFooter({ text: `تم التحديث: ${new Date().toLocaleString('ar-SA')}` });

        return interaction.reply({ embeds: [ticketsEmbed], ephemeral: true });
      }

      if (interaction.customId === 'bottool_restart') {
        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
          return interaction.reply({ content: '❌ ليس لديك صلاحيات إعادة تشغيل البوت', ephemeral: true });
        }

        await interaction.reply({ content: '🔄 جاري إعادة تشغيل البوت...', ephemeral: true });
        console.log(`🔄 Bot is restarting via bottool from ${interaction.user.tag}...`);
        
        setTimeout(() => {
          process.exit(0);
        }, 1000);
      }

      if (interaction.customId === 'bottool_logs') {
        const logsEmbed = new EmbedBuilder()
          .setTitle('📝 سجلات البوت')
          .setDescription('آخر الأنشطة والأحداث')
          .setColor(0x0099ff)
          .addFields([
            { name: '✅ آخر تحديث', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
            { name: '🔄 وقت التشغيل', value: `${Math.floor(client.uptime / 1000)}s`, inline: true },
            { name: '👥 الأعضاء', value: `${interaction.guild.memberCount}`, inline: true }
          ]);

        return interaction.reply({ embeds: [logsEmbed], ephemeral: true });
      }

      if (interaction.customId === 'bottool_voice') {
        const voiceEmbed = new EmbedBuilder()
          .setTitle('🎤 قنوات الصوت')
          .setDescription('حالة اتصالات الصوت')
          .setColor(0x00ff00)
          .addFields([
            { name: 'حالة الاتصال', value: client.voice.adapters.size > 0 ? '✅ متصل' : '❌ غير متصل', inline: true },
            { name: 'عدد الاتصالات', value: `${client.voice.adapters.size}`, inline: true }
          ]);

        return interaction.reply({ embeds: [voiceEmbed], ephemeral: true });
      }
    });
  }
};
