const fs = require('fs');
const path = require('path');

const analyticsPath = path.join(__dirname, 'data', 'analytics.json');

function loadAnalytics() {
    if (!fs.existsSync(analyticsPath)) {
        fs.writeFileSync(analyticsPath, JSON.stringify({ 
            totalTickets: 0, 
            closedTickets: 0,
            avgResponseTime: 0,
            createdAt: new Date().toISOString()
        }, null, 2));
    }
    return JSON.parse(fs.readFileSync(analyticsPath, 'utf-8'));
}

function saveAnalytics(data) {
    fs.writeFileSync(analyticsPath, JSON.stringify(data, null, 2));
}

function recordTicketCreated() {
    const analytics = loadAnalytics();
    analytics.totalTickets++;
    saveAnalytics(analytics);
}

function recordTicketClosed() {
    const analytics = loadAnalytics();
    analytics.closedTickets++;
    saveAnalytics(analytics);
}

function getAnalytics() {
    return loadAnalytics();
}

module.exports = {
    name: 'ticketAnalytics',
    recordTicketCreated,
    recordTicketClosed,
    getAnalytics,
    execute(client) {
        console.log('System Ticket Analytics ✅');
    }
};
