// Code Nexus => https://discord.gg/Tpwgkj9gzj

const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits, REST, Routes, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
require('dotenv').config();

const afkFilePath = path.join(__dirname, 'Commands', 'data', 'afk.json');
const pointsFilePath = path.join(__dirname, 'System', 'data', 'points.json');

const ALLOWED_ROLE_ID = process.env.ALLOWED_ROLE_ID;
const MEMBER = process.env.MEMBER_ROLE;

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates,
    ],
});

client.commands = new Collection();
client.systems = new Collection();
const openedTickets = new Set(); // ⬅️ بدلًا من استخدام ملف

const loadFiles = (directory, callback) => {
    const dirPath = path.join(__dirname, directory);
    if (!fs.existsSync(dirPath)) return console.warn(`[Warning] Directory not found: ${directory}`);

    fs.readdirSync(dirPath).filter(file => file.endsWith('.js')).forEach(file => {
        const filePath = path.join(dirPath, file);
        try {
            const loadedFile = require(filePath);
            callback(file, loadedFile);
        } catch (err) {
            console.error(`[Error] Failed to load file: ${filePath}`, err);
        }
    });
};

// تحسين نظام النقاط باستخدام الكاش في الذاكرة
let pointsData = {};
try { pointsData = JSON.parse(fs.readFileSync(pointsFilePath, 'utf8')); } catch (err) { console.error('❌ Error reading points file:', err); }

const modifyUserPoints = (userId, pointsToAdd) => {
    pointsData[userId] = (pointsData[userId] || 0) + pointsToAdd;
    fs.writeFileSync(pointsFilePath, JSON.stringify(pointsData, null, 2));
};

loadFiles('Commands', (file, command) => {
    if (command.data && typeof command.execute === 'function') client.commands.set(command.data.name, command);
});
loadFiles('System', (file, system) => {
    if (system.name && typeof system.execute === 'function') {
        system.execute(client);
        client.systems.set(system.name, system);
    }
});

const updateSlashCommands = async () => {
    const commands = [...client.commands.values()].map(cmd => cmd.data.toJSON());
    try {
        await new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN)
            .put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
        console.log('✅ Slash commands updated.');
    } catch (error) {
        console.error('❌ Failed to update commands:', error);
    }
};

client.once('ready', async () => {
    console.log('✅ Bot is ready!');
    await updateSlashCommands();
});

client.on('interactionCreate', async (interaction) => {
    try {
        if (interaction.isCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return interaction.reply({ content: '❌ Command not found.', ephemeral: true });
            await command.execute(client, interaction);
        } else if (interaction.isButton()) {
            const { customId, user, member, message } = interaction;
            if (!member.roles.cache.has(MEMBER)) {
                return interaction.reply({ content: '🚫 ليس لديك صلاحية لاستعمال هذه الأزرار.', ephemeral: true });
            }            

            const userId = user.id;
            if (customId === 'claim') {
                modifyUserPoints(userId, 1);
                await interaction.update({
                    embeds: [EmbedBuilder.from(message.embeds[0]).setDescription(`تم استلام التذكرة من طرف ${user}.`).setThumbnail(user.displayAvatarURL())],
                    components: [new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('claim').setLabel('Claim').setStyle(ButtonStyle.Success).setDisabled(true),
                        new ButtonBuilder().setCustomId(`unclaim_${userId}`).setLabel('Unclaim').setStyle(ButtonStyle.Danger).setDisabled(false)
                    )],
                    content: `${user} تم استلام التذكرة.`,
                });
            } else if (customId.startsWith('unclaim_')) {
                const claimedUserId = customId.split('_')[1];
                if (userId !== claimedUserId) return interaction.reply({ content: '🚫 فقط المستلم يمكنه الضغط على هذا الزر.', ephemeral: true });

                modifyUserPoints(userId, -1);
                await interaction.update({
                    embeds: [EmbedBuilder.from(message.embeds[0]).setDescription(`تم سحب استلام التذكرة من طرف ${user}.`).setThumbnail(user.displayAvatarURL())],
                    components: [new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('claim').setLabel('Claim').setStyle(ButtonStyle.Success).setDisabled(false),
                        new ButtonBuilder().setCustomId(`unclaim_${userId}`).setLabel('Unclaim').setStyle(ButtonStyle.Danger).setDisabled(true)
                    )],
                    content: `${user} تم سحب استلام التذكرة.`,
                });
            } else if (customId === 'openTicket') {
                if (!openedTickets.has(userId)) {
                    openedTickets.add(userId);
                    const embed = new EmbedBuilder().setDescription(`تم فتح التذكرة من طرف ${user}.`).setThumbnail(user.displayAvatarURL());
                    const buttons = new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('claim').setLabel('Claim').setStyle(ButtonStyle.Success),
                        new ButtonBuilder().setCustomId(`unclaim_${userId}`).setLabel('Unclaim').setStyle(ButtonStyle.Danger).setDisabled(true)
                    );
                    await interaction.reply({ content: `${user} تم فتح التذكرة.`, embeds: [embed], components: [buttons] });
                } else {
                    return interaction.reply({ content: '❌ لديك بالفعل تذكرة مفتوحة!', ephemeral: true });
                }
            }
        }
    } catch (error) {
        console.error('❌ Error handling interaction:', error);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'حدث خطأ أثناء معالجة طلبك.', ephemeral: true });
        } else {
            await interaction.followUp({ content: 'حدث خطأ أثناء معالجة طلبك.', ephemeral: true });
        }
    }
});

// نظام AFK محسن
let afkData = {};
try { afkData = JSON.parse(fs.readFileSync(afkFilePath, 'utf8')); } catch (err) { console.error('❌ Error reading afk file:', err); }

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (message.mentions.users.size) {
        message.mentions.users.forEach(user => {
            if (afkData[user.id]) message.reply(`${user.username} هو في حالة AFK بسبب: ${afkData[user.id].reason}`);
        });
    }
    if (afkData[message.author.id]) {
        delete afkData[message.author.id];
        fs.writeFileSync(afkFilePath, JSON.stringify(afkData, null, 2));
        message.reply(`أهلاً بعودتك ${message.author.username}! تم إزالة حالة AFK.`);
    }
});

client.login(process.env.DISCORD_TOKEN);

// Code Nexus => https://discord.gg/Tpwgkj9gzj