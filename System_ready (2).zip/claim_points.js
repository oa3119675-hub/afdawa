const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const CATEGORY_IDS = process.env.CATEGORY_IDS ? process.env.CATEGORY_IDS.split(',') : [];

module.exports = {
  name: 'claim_points', 
  execute(client) {
    client.on('channelCreate', async (channel) => {
      try {
        if (CATEGORY_IDS.length > 0 && CATEGORY_IDS.includes(channel.parentId)) {
          setTimeout(async () => {
            const embed = new EmbedBuilder()
              .setColor('#5865F2')
              .setTitle('نظام التذاكر')
              .setDescription('استخدم الأزرار لاستلام التذكرة أو سحبها.')
              .setFooter({ text: 'Bot by: Shaad You', iconURL: client.user.displayAvatarURL() });

            const buttons = new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('claim').setLabel('Claim').setStyle(ButtonStyle.Success),
              new ButtonBuilder().setCustomId('unclaim').setLabel('Unclaim').setStyle(ButtonStyle.Danger).setDisabled(true)
            );

            await channel.send({ embeds: [embed], components: [buttons] });
            console.log(`Embed sent successfully in channel: ${channel.name}`);
          }, 5000);
        }
      } catch (error) {
        console.error('❌ Error in channelCreate event:', error);
      }
    });
  }
};
